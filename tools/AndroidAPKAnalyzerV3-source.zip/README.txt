ANDROID APK ANALYZER v3.3 — POLICE FORENSIC EDITION

Purpose:
Static APK forensic triage and investigation support. The tool does NOT execute the APK.

Files:
- android_forensic.py       Core analyzer and report generator
- android_forensic_gui.py   Windows GUI
- AndroidAPKAnalyzerV3.spec PyInstaller configuration
- setup_and_build.bat       Windows build script
- requirements.txt           Python dependencies
- rules/                     Optional YARA rules

Build on Windows:
1. Install Python 3.11+ and enable Add Python to PATH.
2. Keep all files in this folder.
3. Run setup_and_build.bat.
4. EXE will be created under dist\\.

Optional threat intelligence:
Set VT_API_KEY and/or ABUSEIPDB_API_KEY as environment variables before running.
No APK is uploaded automatically merely by selecting it. External lookups occur only
when configured and enabled.

Forensic limitation:
This is static triage. Findings are investigative leads and require manual, decompilation,
and/or dynamic validation. Absence of a finding does not establish absence of the behavior.

Recommended evidence practice:
Record the original APK SHA-256, source/location, acquisition time, analyst identity,
and preserve the original evidence unchanged. Keep generated reports with the original
case/evidence identifiers.
