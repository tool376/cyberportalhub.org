import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
import webbrowser
import threading
import hashlib
import os
import sys
import subprocess

from android_forensic import generate

APP_NAME = "Android APK Analyzer v3.3 — Developed by Rajesh Dhyani"

BG = "#07111d"
PANEL = "#0d1b2a"
PANEL2 = "#102438"
TEXT = "#eaf4ff"
MUTED = "#9db2c7"
ACCENT = "#16c7ff"
ACCENT2 = "#278cff"
GREEN = "#31d158"
RED = "#ff5c5c"
BORDER = "#1d405d"

class AnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1180x760")
        self.root.minsize(1000, 680)
        self.root.configure(bg=BG)
        self.apk_path = None
        self.report_path = None
        self.json_path = None
        self.build()

    def label(self, parent, text, size=11, bold=False, color=TEXT, **kw):
        return tk.Label(parent, text=text, font=("Segoe UI", size, "bold" if bold else "normal"),
                        bg=parent.cget("bg"), fg=color, **kw)

    def button(self, parent, text, command, bg=ACCENT2, width=20):
        return tk.Button(parent, text=text, command=command, font=("Segoe UI", 10, "bold"),
                         bg=bg, fg="white", activebackground=ACCENT, activeforeground="white",
                         relief="flat", bd=0, padx=12, pady=9, cursor="hand2", width=width)

    def build(self):
        header = tk.Frame(self.root, bg="#06101a", height=76)
        header.pack(fill="x")
        header.pack_propagate(False)
        self.label(header, "▣", 32, True, ACCENT).pack(side="left", padx=(24,8))
        titlebox = tk.Frame(header, bg="#06101a")
        titlebox.pack(side="left", pady=12)
        self.label(titlebox, "ANDROID APK ANALYZER", 21, True).pack(anchor="w")
        self.label(titlebox, "v3.3  •  OWASP Mobile Top 10  •  MASVS  •  Evidence Triage", 9, False, MUTED).pack(anchor="w")
        rightbox = tk.Frame(header, bg="#06101a")
        rightbox.pack(side="right", padx=25)
        self.label(rightbox, "Developed by Rajesh Dhyani", 10, True, ACCENT).pack(anchor="e")
        self.label(rightbox, "STATIC  |  YARA  |  SDK  |  SECRETS  |  OWASP  |  DEX", 8, False, MUTED).pack(anchor="e")

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=18, pady=16)

        side = tk.Frame(body, bg=PANEL, width=220, highlightbackground=BORDER, highlightthickness=1)
        side.pack(side="left", fill="y", padx=(0,14))
        side.pack_propagate(False)

        self.label(side, "FORENSIC MODULES", 10, True, ACCENT).pack(anchor="w", padx=18, pady=(20,12))
        modules = [
            ("⌂", "Dashboard"),
            ("▣", "APK Analysis"),
            ("⚙", "Manifest & Permissions"),
            ("✓", "Certificate & Integrity"),
            ("◎", "Network / IOC"),
            ("☣", "YARA Scan"),
            ("◈", "Threat Intelligence"),
            ("🛡", "OWASP Mobile Top 10"),
            ("▤", "Extracted Artifacts"),
            ("▥", "Forensic Reports"),
        ]
        for icon, name in modules:
            f=tk.Frame(side,bg=PANEL,height=42)
            f.pack(fill="x", padx=8, pady=1)
            self.label(f, icon, 14, True, ACCENT).pack(side="left", padx=(10,12))
            self.label(f,name,10,True if name=="APK Analysis" else False).pack(side="left")

        self.label(side, "AUTHORIZED INVESTIGATION USE", 8, True, MUTED, justify="center").pack(side="bottom", pady=(10,3))
        self.label(side, "Static analysis only • No APK execution • Evidence stays local", 8, False, MUTED, justify="center").pack(side="bottom", pady=(0,16))

        content = tk.Frame(body, bg=BG)
        content.pack(side="left", fill="both", expand=True)

        filecard = tk.Frame(content,bg=PANEL2,highlightbackground=BORDER,highlightthickness=1)
        filecard.pack(fill="x")
        top=tk.Frame(filecard,bg=PANEL2)
        top.pack(fill="x",padx=18,pady=14)
        self.label(top,"SELECT APK EVIDENCE",12,True).pack(side="left")
        self.status = self.label(top,"● READY",9,True,GREEN)
        self.status.pack(side="right")
        row=tk.Frame(filecard,bg=PANEL2)
        row.pack(fill="x",padx=18,pady=(0,16))
        self.path_var=tk.StringVar(value="No APK selected")
        ent=tk.Entry(row,textvariable=self.path_var,font=("Segoe UI",10),bg="#081521",fg=TEXT,
                     insertbackground=TEXT,relief="flat",bd=0)
        ent.pack(side="left",fill="x",expand=True,ipady=10,padx=(0,10))
        self.button(row,"Browse APK",self.select_apk,width=15).pack(side="right")

        facts=tk.Frame(content,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        facts.pack(fill="x",pady=12)
        self.fact_file=self.fact(facts,"FILE","—")
        self.fact_size=self.fact(facts,"SIZE","—")
        self.fact_hash=self.fact(facts,"SHA-256","—")
        self.fact_file.pack(side="left",fill="x",expand=True,padx=12,pady=12)
        self.fact_size.pack(side="left",fill="x",expand=True,padx=12,pady=12)
        self.fact_hash.pack(side="left",fill="x",expand=True,padx=12,pady=12)

        grid=tk.Frame(content,bg=BG)
        grid.pack(fill="both",expand=True)
        left=tk.Frame(grid,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        left.pack(side="left",fill="both",expand=True,padx=(0,7))
        right=tk.Frame(grid,bg=PANEL,highlightbackground=BORDER,highlightthickness=1,width=280)
        right.pack(side="right",fill="y",padx=(7,0))
        right.pack_propagate(False)

        self.label(left,"ANALYSIS OPTIONS",12,True).pack(anchor="w",padx=18,pady=(16,8))
        options=[
            "Basic APK Information","Manifest & Permissions","Extract Strings & Artifacts",
            "YARA Rule Scanning","Network & Domain Analysis","Threat Intelligence Lookup",
            "DEX / Static Code Indicators","Detect Embedded Files","Generate HTML / TXT / CSV Report"
        ]
        options_frame = tk.Frame(left, bg=PANEL)
        options_frame.pack(fill="x", padx=4, pady=2)

        self.option_vars = {}
        for i,opt in enumerate(options):
            var=tk.BooleanVar(value=True)
            self.option_vars[opt] = var
            cb=tk.Checkbutton(
                options_frame, text=opt, variable=var,
                bg=PANEL, fg=TEXT, selectcolor="#12314a",
                activebackground=PANEL, activeforeground=TEXT,
                font=("Segoe UI",9), anchor="w"
            )
            cb.grid(row=i//2, column=i%2, sticky="w", padx=14, pady=5)
        options_frame.grid_columnconfigure(0, weight=1)
        options_frame.grid_columnconfigure(1, weight=1)

        self.start_btn=self.button(left,"▶  START FORENSIC ANALYSIS",self.start_analysis,width=30)
        self.start_btn.pack(pady=20)

        self.label(right,"QUICK ACTIONS",12,True).pack(anchor="w",padx=16,pady=(16,10))
        self.button(right,"Select APK",self.select_apk).pack(padx=16,pady=5,fill="x")
        self.open_btn=self.button(right,"📂 Open Last Report",self.open_last,bg="#1d4664")
        self.open_btn.pack(padx=16,pady=5,fill="x")
        self.button(right,"Open Report Folder",self.open_folder,bg="#1d4664").pack(padx=16,pady=5,fill="x")
        self.button(right,"🛡 Open OWASP Guide",self.open_owasp_guide,bg="#1d4664").pack(padx=16,pady=5,fill="x")
        self.button(right,"Open VirusTotal",self.open_virustotal,bg="#1d4664").pack(padx=16,pady=5,fill="x")
        self.button(right,"Exit",self.root.destroy,bg="#8f3030").pack(padx=16,pady=(18,5),fill="x")

        self.log=tk.Text(right,height=10,bg="#07111d",fg="#8fffa4",insertbackground=TEXT,
                         relief="flat",font=("Consolas",8),wrap="word")
        self.log.pack(fill="both",expand=True,padx=12,pady=14)
        self.log_insert("Ready. Select an APK to begin analysis.\n")

        footer=tk.Frame(content,bg=BG)
        footer.pack(fill="x",pady=(10,0))
        self.label(footer,"Evidence is not uploaded automatically. VirusTotal/AbuseIPDB use only configured external lookups; record their results separately from local evidence.",
                   8,False,MUTED).pack(side="left")
        self.label(footer,"Android APK Analyzer v3.3 — Police Forensic Edition",8,True,MUTED).pack(side="right")

    def fact(self,parent,k,v):
        f=tk.Frame(parent,bg=parent.cget("bg"))
        tk.Label(f,text=k,bg=parent.cget("bg"),fg=MUTED,font=("Segoe UI",8,"bold")).pack(anchor="w")
        lab=tk.Label(f,text=v,bg=parent.cget("bg"),fg=TEXT,font=("Segoe UI",9,"bold"),wraplength=260,anchor="w",justify="left")
        lab.pack(anchor="w",pady=(3,0))
        f.value=lab
        return f

    def log_insert(self,text):
        self.log.insert("end",text)
        self.log.see("end")

    # ===== Reliable file opener (Windows: os.startfile) =====
    def _open_path(self, path) -> bool:
        if not path or not Path(path).exists():
            return False
        p = Path(path).resolve()
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(p))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
            return True
        except Exception as e1:
            try:
                return webbrowser.open(p.as_uri())
            except Exception as e2:
                self.log_insert(f"Failed to open report: {e1} / {e2}\n")
                return False

    def select_apk(self):
        p=filedialog.askopenfilename(title="Select APK Evidence",filetypes=[("Android APK","*.apk"),("All files","*.*")])
        if not p:return
        self.apk_path=Path(p)
        self.path_var.set(str(self.apk_path))
        self.status.config(text="● APK LOADED",fg=GREEN)
        self.fact_file.value.config(text=self.apk_path.name)
        self.fact_size.value.config(text=f"{self.apk_path.stat().st_size:,} bytes")
        try:
            h=hashlib.sha256()
            with open(self.apk_path,"rb") as f:
                for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
            self.fact_hash.value.config(text=h.hexdigest()[:24]+"…")
        except: pass
        self.log_insert(f"\n[{self.apk_path.name}] Loaded.\n")
        self.start_analysis()

    def start_analysis(self):
        if not self.apk_path:
            self.select_apk(); return
        self.start_btn.config(state="disabled",text="⏳  ANALYZING…")
        self.status.config(text="● ANALYSIS RUNNING",fg="#ffd166")
        self.log_insert("Starting static forensic analysis...\n")
        threading.Thread(target=self.worker,daemon=True).start()

    def worker(self):
        try:
            out=self.apk_path.parent
            options={name:var.get() for name,var in self.option_vars.items()}
            vt_key=os.environ.get("VT_API_KEY")
            abuseipdb_key=os.environ.get("ABUSEIPDB_API_KEY")
            base,data=generate(self.apk_path,out,vt_key,abuseipdb_key,options)

            html_path = base.with_suffix(".html")
            json_path = base.with_suffix(".json")

            # Emergency HTML regenerate if option unchecked but user still wants to view
            if not html_path.exists():
                try:
                    from android_forensic import render_html
                    html_path.write_text(render_html(data), encoding="utf-8")
                    self.root.after(0, lambda: self.log_insert("Note: HTML regenerated (was skipped by option).\n"))
                except Exception as e:
                    self.root.after(0, lambda msg=f"Could not regenerate HTML: {e}\n": self.log_insert(msg))

            self.report_path = html_path if html_path.exists() else None
            self.json_path = json_path if json_path.exists() else None
            self.root.after(0, self.analysis_done, data)
        except Exception as e:
            self.root.after(0,self.analysis_error,str(e))

    def analysis_done(self,data):
        self.start_btn.config(state="normal",text="▶  START FORENSIC ANALYSIS")
        self.status.config(text=f"● {data['level']} RISK",fg=RED if data["level"] in ("HIGH","CRITICAL") else GREEN)
        self.log_insert("─" * 40 + "\n")
        self.log_insert(f"✓ Complete. Risk: {data['level']} (score {data['score']})\n")
        self.log_insert(f"  SDKs: {len(data.get('sdks',[]))} | "
                        f"Secrets: {len(data.get('secrets',[]))} | "
                        f"Certs: {len(data.get('certificates',[]))}\n")
        dex = data.get("dex", {})
        self.log_insert(f"  DEX classes: {dex.get('class_count',0)} | "
                        f"Methods: {dex.get('method_count',0)}\n")

        # ===== OWASP summary in log =====
        owasp = data.get("owasp", {}) or {}
        owasp_total = owasp.get("summary", {}).get("total", 0)
        if owasp_total:
            by_sev = owasp["summary"].get("by_severity", {})
            crit = by_sev.get("CRITICAL", 0)
            high = by_sev.get("HIGH", 0)
            med  = by_sev.get("MEDIUM", 0)
            low  = by_sev.get("LOW", 0)
            self.log_insert(f"🛡 OWASP Mobile Top 10: {owasp_total} issue(s)\n")
            self.log_insert(f"   CRITICAL={crit} HIGH={high} MEDIUM={med} LOW={low}\n")
            # show top 3 findings
            top_findings = owasp.get("findings", [])[:3]
            if top_findings:
                self.log_insert("   Top findings:\n")
                for f in top_findings:
                    self.log_insert(f"   • [{f['severity']}] {f['id']} {f['category']}\n")
        else:
            self.log_insert("🛡 OWASP: no issues detected (good)\n")

        # Cloud misconfig
        if data.get("cloud_alerts"):
            self.log_insert(f"⚠ {len(data['cloud_alerts'])} cloud misconfig alert(s)!\n")
        if data.get("secrets"):
            self.log_insert("⚠ Hardcoded secrets मिले — HTML report देखें।\n")

        # Open report
        if self.report_path:
            self.log_insert(f"Report: {self.report_path.name}\n")
            opened = self._open_path(self.report_path)
            if not opened:
                self.root.after(500, self._retry_open)
        else:
            self.log_insert("HTML report was not generated (option unchecked).\n")
            if self.json_path and self.json_path.exists():
                self.log_insert("Opening JSON instead...\n")
                self._open_path(self.json_path)

    def _retry_open(self):
        if self.report_path and self.report_path.exists():
            if self._open_path(self.report_path):
                self.log_insert("Report opened (retry).\n")
                return
        messagebox.showwarning(APP_NAME,
            "Report बन गई है लेकिन अपने आप नहीं खुली।\n"
            "'📂 Open Last Report' button दबाएँ या folder से manually खोलें।")

    def analysis_error(self,msg):
        self.start_btn.config(state="normal",text="▶  START FORENSIC ANALYSIS")
        self.status.config(text="● ERROR",fg=RED)
        self.log_insert("ERROR: "+msg+"\n")
        messagebox.showerror(APP_NAME,msg)

    def open_last(self):
        if self.report_path and self.report_path.exists():
            if not self._open_path(self.report_path):
                messagebox.showerror(APP_NAME, f"Could not open:\n{self.report_path}")
        elif self.json_path and self.json_path.exists():
            self._open_path(self.json_path)
        else:
            messagebox.showinfo(APP_NAME,"No report generated in this session.")

    def open_folder(self):
        if self.apk_path:
            try:
                if sys.platform.startswith("win"):
                    os.startfile(str(self.apk_path.parent))
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", str(self.apk_path.parent)])
                else:
                    subprocess.Popen(["xdg-open", str(self.apk_path.parent)])
            except Exception as e:
                messagebox.showerror(APP_NAME, f"Could not open folder:\n{e}")
        else:
            messagebox.showinfo(APP_NAME,"Select an APK first.")

    def open_owasp_guide(self):
        """Open OWASP Mobile Top 10 (2024) official page."""
        try:
            webbrowser.open("https://owasp.org/www-project-mobile-top-10/")
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not open browser:\n{e}")

    def open_virustotal(self):
        if self.apk_path and self.apk_path.exists():
            try:
                h=hashlib.sha256()
                with open(self.apk_path,"rb") as f:
                    for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
                url = f"https://www.virustotal.com/gui/file/{h.hexdigest()}"
                webbrowser.open(url)
                return
            except Exception:
                pass
        webbrowser.open("https://www.virustotal.com/")

if __name__=="__main__":
    root=tk.Tk()
    app=AnalyzerGUI(root)
    root.mainloop()