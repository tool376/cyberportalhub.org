#!/usr/bin/env python3
"""
Android APK Analyzer v3.3 Police Forensic Edition
Static APK triage with:
- hashes / ZIP inventory
- strict domain / phone / secret filtering (v3.1 fixes)
- 150+ provider classification (Firebase, AWS, Azure, GCP, Supabase, ...)
- SDK detection + category grouping
- hardcoded secrets / API keys
- APK signing certificate parsing
- AndroidManifest.xml parsing (permissions + risk levels, deep links)
- DEX header + interesting class extraction
- Native library (.so) inventory
- APK structure breakdown
- Embedded payload detection
- Third-party library version detection
- Cloud misconfiguration alerts (Firebase / Supabase)
- Clean network URL extraction
- Suspicious endpoint / potential C2 heuristics
- OWASP Mobile Top 10 (2024) + MASVS mapping  ← NEW in v3.2
- optional YARA (yara-python)
- optional VirusTotal hash lookup
- optional AbuseIPDB IP lookup
- HTML/TXT/CSV/JSON reports with investigation checklist
No APK execution.
"""

import argparse, csv, hashlib, html, io, json, os, re, struct, sys, urllib.parse, zipfile
from datetime import datetime, timezone
from pathlib import Path

# ---------- Provider database ----------
PROVIDERS = [
    ("Firebase Realtime DB", [r"firebaseio\.com$", r"[a-z0-9-]+\.firebaseio\.com$"]),
    ("Firebase Hosting",     [r"firebaseapp\.com$", r"web\.app$"]),
    ("Firebase Cloud Messaging", [r"fcm\.googleapis\.com$", r"firebaseinstallations\.googleapis\.com$"]),
    ("Firebase Auth",        [r"identitytoolkit\.googleapis\.com$", r"securetoken\.googleapis\.com$"]),
    ("Firebase Storage",     [r"firebasestorage\.googleapis\.com$", r"firebasestorage\.app$"]),
    ("Firebase Crashlytics", [r"crashlytics\.com$", r"firebase-settings\.crashlytics\.com$"]),
    ("Firebase Remote Config", [r"firebaseremoteconfig\.googleapis\.com$"]),
    ("Firebase ML Kit",      [r"mlkit\.googleapis\.com$"]),
    ("Google APIs",          [r"googleapis\.com$", r"googleusercontent\.com$", r"gstatic\.com$", r"google\.com$", r"googlesyndication\.com$", r"googleadservices\.com$", r"doubleclick\.net$"]),
    ("Google Play",          [r"play\.google\.com$", r"android\.clients\.google\.com$"]),
    ("Google Analytics",     [r"google-analytics\.com$", r"analytics\.google\.com$", r"googletagmanager\.com$"]),
    ("Google Cloud",         [r"appspot\.com$", r"cloudfunctions\.net$", r"run\.app$", r"storage\.cloud\.google\.com$"]),
    ("AWS S3",               [r"s3[.\-][a-z0-9\-]*\.amazonaws\.com$", r"s3\.amazonaws\.com$"]),
    ("AWS API Gateway",      [r"execute-api\.[a-z0-9\-]+\.amazonaws\.com$"]),
    ("AWS CloudFront",       [r"cloudfront\.net$"]),
    ("AWS Cognito",          [r"cognito-idp\.[a-z0-9\-]+\.amazonaws\.com$", r"cognito-identity\.[a-z0-9\-]+\.amazonaws\.com$"]),
    ("AWS DynamoDB",         [r"dynamodb\.[a-z0-9\-]+\.amazonaws\.com$"]),
    ("AWS Lambda",           [r"lambda-url\.[a-z0-9\-]+\.on\.aws$", r"\.lambda-url\.amazonaws\.com$"]),
    ("AWS Amplify",          [r"amplifyapp\.com$"]),
    ("AWS General",          [r"amazonaws\.com$"]),
    ("Azure Web Apps",       [r"azurewebsites\.net$"]),
    ("Azure Blob",           [r"blob\.core\.windows\.net$"]),
    ("Azure CDN",            [r"azureedge\.net$", r"azurefd\.net$"]),
    ("Azure SQL",            [r"database\.windows\.net$"]),
    ("Azure AD / B2C",       [r"login\.microsoftonline\.com$", r"b2clogin\.com$"]),
    ("Azure Notification Hubs", [r"servicebus\.windows\.net$"]),
    ("Azure Static Apps",    [r"azurestaticapps\.net$"]),
    ("Microsoft Graph",      [r"graph\.microsoft\.com$"]),
    ("Microsoft General",    [r"microsoft\.com$", r"live\.com$", r"msn\.com$"]),
    ("Cloudflare Workers",   [r"workers\.dev$"]),
    ("Cloudflare Pages",     [r"pages\.dev$"]),
    ("Cloudflare R2",        [r"r2\.cloudflarestorage\.com$"]),
    ("Cloudflare",           [r"cloudflare\.com$", r"cloudflarestream\.com$", r"cloudflareapps\.com$"]),
    ("Supabase",             [r"supabase\.co$", r"supabase\.in$"]),
    ("MongoDB Atlas",        [r"mongodb\.net$", r"realm\.mongodb\.com$"]),
    ("Appwrite",             [r"appwrite\.io$", r"cloud\.appwrite\.io$"]),
    ("Back4App / Parse",     [r"back4app\.io$", r"parseplatform\.org$", r"parse\.com$"]),
    ("Backendless",          [r"backendless\.com$", r"backendlessappcontent\.com$"]),
    ("Kinvey",               [r"kinvey\.com$"]),
    ("Kii Cloud",            [r"kiiapps\.com$", r"kii\.com$"]),
    ("Nhost",                [r"nhost\.run$", r"nhost\.io$"]),
    ("PocketBase",           [r"pocketbase\.io$"]),
    ("Directus",             [r"directus\.io$"]),
    ("Strapi",               [r"strapi\.io$"]),
    ("Heroku",               [r"herokuapp\.com$", r"herokudns\.com$"]),
    ("Vercel",               [r"vercel\.app$", r"vercel\.com$", r"now\.sh$"]),
    ("Netlify",              [r"netlify\.app$", r"netlify\.com$"]),
    ("Render",               [r"onrender\.com$"]),
    ("Railway",              [r"railway\.app$", r"up\.railway\.app$"]),
    ("Fly.io",               [r"fly\.dev$"]),
    ("Glitch",               [r"glitch\.me$"]),
    ("Replit",               [r"repl\.co$", r"replit\.dev$"]),
    ("DigitalOcean",         [r"digitaloceanspaces\.com$", r"ondigitalocean\.app$"]),
    ("Linode",               [r"linode\.com$", r"linodeobjects\.com$"]),
    ("Vultr",                [r"vultr\.com$", r"vultrobjects\.com$"]),
    ("Alibaba Cloud",        [r"aliyuncs\.com$", r"alibaba\.com$", r"alicdn\.com$", r"aliyun\.com$"]),
    ("Tencent Cloud",        [r"myqcloud\.com$", r"tencent\.com$", r"qcloud\.com$", r"tencentcs\.com$"]),
    ("Huawei Cloud",         [r"huaweicloud\.com$", r"hwclouds\.com$", r"huawei\.com$"]),
    ("Baidu Cloud",          [r"baidubce\.com$", r"baidu\.com$"]),
    ("Oracle Cloud",         [r"oraclecloud\.com$", r"oracle\.com$"]),
    ("IBM Cloud",            [r"cloud\.ibm\.com$", r"ibm\.com$"]),
    ("OneSignal",            [r"onesignal\.com$"]),
    ("Pusher",               [r"pusher\.com$", r"pusherapp\.com$"]),
    ("PubNub",               [r"pubnub\.com$", r"pndsn\.com$"]),
    ("Airship (Urban)",      [r"urbanairship\.com$", r"airship\.com$"]),
    ("Braze (Appboy)",       [r"braze\.com$", r"appboy\.com$"]),
    ("Leanplum",             [r"leanplum\.com$"]),
    ("CleverTap",            [r"clevertap\.com$", r"clevertap-prod\.com$"]),
    ("MoEngage",             [r"moengage\.com$", r"moengage\.in$"]),
    ("WebEngage",            [r"webengage\.com$", r"webengage\.co$"]),
    ("Netcore / Smartech",   [r"netcorecloud\.com$", r"smartech\.net$"]),
    ("Iterable",             [r"iterable\.com$"]),
    ("Customer.io",          [r"customer\.io$"]),
    ("WonderPush",           [r"wonderpush\.com$"]),
    ("Batch",                [r"batch\.com$"]),
    ("Mixpanel",             [r"mixpanel\.com$"]),
    ("Amplitude",            [r"amplitude\.com$"]),
    ("AppsFlyer",            [r"appsflyer\.com$", r"appsflyersdk\.com$"]),
    ("Adjust",               [r"adjust\.com$", r"adj\.st$"]),
    ("Branch",               [r"branch\.io$", r"app\.link$"]),
    ("Kochava",              [r"kochava\.com$", r"kv8s\.com$"]),
    ("Singular",             [r"singular\.net$"]),
    ("Tenjin",               [r"tenjin\.com$", r"tenjin\.io$"]),
    ("AppMetrica (Yandex)",  [r"appmetrica\.yandex\.net$", r"yandex\.net$", r"yandex\.ru$"]),
    ("Flurry",               [r"flurry\.com$", r"yahoapis\.com$"]),
    ("Localytics",           [r"localytics\.com$"]),
    ("Countly",              [r"count\.ly$", r"countly\.com$"]),
    ("Matomo",               [r"matomo\.org$", r"piwik\.org$"]),
    ("Segment",              [r"segment\.io$", r"segment\.com$"]),
    ("mParticle",            [r"mparticle\.com$"]),
    ("Heap",                 [r"heap\.io$"]),
    ("PostHog",              [r"posthog\.com$", r"i\.posthog\.com$"]),
    ("AdMob",                [r"admob\.com$", r"googleadservices\.com$", r"googlesyndication\.com$"]),
    ("Facebook Audience",    [r"facebook\.com$", r"fbcdn\.net$", r"facebook\.net$", r"fb\.me$"]),
    ("Unity Ads",            [r"unityads\.unity3d\.com$", r"unity3d\.com$"]),
    ("AppLovin",             [r"applovin\.com$", r"applvn\.com$"]),
    ("ironSource",           [r"ironsrc\.com$", r"supersonicads\.com$", r"ironsource\.mobi$"]),
    ("Vungle",               [r"vungle\.com$"]),
    ("AdColony",             [r"adcolony\.com$"]),
    ("Chartboost",           [r"chartboost\.com$"]),
    ("Mintegral",            [r"mintegral\.com$"]),
    ("Pangle (ByteDance)",   [r"pangleglobal\.com$", r"byteoversea\.com$", r"tiktokv\.com$", r"ibytedtos\.com$"]),
    ("MoPub",                [r"mopub\.com$"]),
    ("InMobi",               [r"inmobi\.com$"]),
    ("Smaato",               [r"smaato\.com$", r"smaato\.net$"]),
    ("Criteo",               [r"criteo\.com$", r"criteo\.net$"]),
    ("Stripe",               [r"stripe\.com$", r"stripe\.network$"]),
    ("Razorpay",             [r"razorpay\.com$"]),
    ("PayPal",               [r"paypal\.com$", r"paypalobjects\.com$"]),
    ("Braintree",            [r"braintreegateway\.com$", r"braintree-api\.com$"]),
    ("Square",               [r"squareup\.com$", r"square\.com$"]),
    ("Adyen",                [r"adyen\.com$"]),
    ("PayU",                 [r"payu\.com$", r"payu\.in$"]),
    ("Cashfree",             [r"cashfree\.com$", r"cashfree\.in$"]),
    ("PhonePe",              [r"phonepe\.com$"]),
    ("Paytm",                [r"paytm\.com$", r"paytmbank\.com$"]),
    ("Google Pay",           [r"googlepay\.com$", r"gpay\.app$"]),
    ("Auth0",                [r"auth0\.com$"]),
    ("Okta",                 [r"okta\.com$", r"oktapreview\.com$"]),
    ("Clerk",                [r"clerk\.com$", r"clerk\.dev$"]),
    ("Magic",                [r"magic\.link$"]),
    ("Sentry",               [r"sentry\.io$", r"ingest\.sentry\.io$"]),
    ("Bugsnag",              [r"bugsnag\.com$"]),
    ("New Relic",            [r"newrelic\.com$", r"nr-data\.net$"]),
    ("Datadog",              [r"datadoghq\.com$", r"ddogapi\.com$"]),
    ("Rollbar",              [r"rollbar\.com$"]),
    ("LogRocket",            [r"logrocket\.com$", r"lr-ingest\.io$"]),
    ("Instabug",             [r"instabug\.com$"]),
    ("Firebase Perf",        [r"firebaseperf\.googleapis\.com$"]),
    ("Google Maps",          [r"maps\.googleapis\.com$", r"maps\.gstatic\.com$"]),
    ("Mapbox",               [r"mapbox\.com$", r"mapbox\.cn$"]),
    ("Here Maps",            [r"here\.com$", r"api\.here\.com$"]),
    ("TomTom",               [r"tomtom\.com$", r"tomtomgroup\.com$"]),
    ("OpenStreetMap",        [r"openstreetmap\.org$", r"tile\.openstreetmap\.org$"]),
    ("Twilio",               [r"twilio\.com$"]),
    ("SendGrid",             [r"sendgrid\.com$", r"sendgrid\.net$"]),
    ("Mailgun",              [r"mailgun\.com$", r"mailgun\.net$"]),
    ("Mailchimp",            [r"mailchimp\.com$", r"list-manage\.com$"]),
    ("Postmark",             [r"postmarkapp\.com$"]),
    ("Slack",                [r"slack\.com$", r"slack-edge\.com$"]),
    ("Discord",              [r"discord\.com$", r"discordapp\.com$", r"discord\.gg$"]),
    ("Telegram",             [r"telegram\.org$", r"t\.me$", r"telegram\.me$"]),
    ("WhatsApp",             [r"whatsapp\.com$", r"whatsapp\.net$"]),
    ("Intercom",             [r"intercom\.com$", r"intercom\.io$"]),
    ("Zendesk",              [r"zendesk\.com$"]),
    ("Freshdesk",            [r"freshdesk\.com$", r"freshworks\.com$"]),
    ("YouTube",              [r"youtube\.com$", r"youtu\.be$", r"ytimg\.com$", r"googlevideo\.com$"]),
    ("Vimeo",                [r"vimeo\.com$", r"vimeocdn\.com$"]),
    ("Twitch",               [r"twitch\.tv$", r"ttvnw\.net$"]),
    ("Agora",                [r"agora\.io$", r"agoralab\.co$"]),
    ("Zoom",                 [r"zoom\.us$"]),
    ("Jitsi",                [r"jitsi\.org$", r"8x8\.vc$"]),
    ("Cloudinary",           [r"cloudinary\.com$"]),
    ("Imgix",                [r"imgix\.net$"]),
    ("Mux",                  [r"mux\.com$"]),
    ("OpenAI",               [r"openai\.com$", r"oaistatic\.com$", r"oaiusercontent\.com$"]),
    ("Anthropic",            [r"anthropic\.com$", r"claude\.ai$"]),
    ("Google Gemini",        [r"generativelanguage\.googleapis\.com$"]),
    ("HuggingFace",          [r"huggingface\.co$", r"hf\.co$"]),
    ("Cohere",               [r"cohere\.ai$", r"cohere\.com$"]),
    ("Replicate",            [r"replicate\.com$", r"replicate\.delivery$"]),
]

LIBRARY_DOMAINS = {
    "android.com", "apache.org", "cordova.apache.org", "fsf.org", "iptc.org",
    "adobe.com", "itextpdf.com", "w3.org", "schemas.android.com", "jetbrains.com",
    "youtrack.jetbrains.com", "developer.android.com", "github.com",
    "kotlinlang.org", "kotlin.org", "gradle.org", "maven.org", "json.org",
    "oracle.com", "eclipse.org", "bouncycastle.org", "slf4j.org", "junit.org",
}

SDK_SIGNATURES = {
    "Firebase Core":       (r"com/google/firebase/FirebaseApp|FirebaseApp", "Analytics"),
    "Firebase Firestore":  (r"FirebaseFirestore|com/google/firebase/firestore", "Database"),
    "Firebase RealtimeDB": (r"FirebaseDatabase|com/google/firebase/database", "Database"),
    "Firebase Storage":    (r"FirebaseStorage|com/google/firebase/storage", "Storage"),
    "Firebase Auth":       (r"FirebaseAuth|com/google/firebase/auth", "Auth"),
    "Firebase Crashlytics":(r"com/google/firebase/crashlytics|Crashlytics", "Crash"),
    "Firebase Analytics":  (r"com/google/firebase/analytics|FirebaseAnalytics", "Analytics"),
    "Firebase Messaging":  (r"FirebaseMessaging|com/google/firebase/messaging", "Push"),
    "Google Play Services":(r"com/google/android/gms", "Google"),
    "Google Analytics":    (r"com/google/android/gms/analytics|GoogleAnalytics", "Analytics"),
    "AdMob":               (r"com/google/android/gms/ads|AdView|MobileAds", "Advertising"),
    "Facebook SDK":        (r"com/facebook/|FacebookSdk|com\.facebook\.", "Social"),
    "Facebook Login":      (r"com/facebook/login|LoginButton", "Social"),
    "AppsFlyer":           (r"com/appsflyer|AppsFlyer", "Analytics"),
    "Adjust":              (r"com/adjust/sdk|Adjust", "Analytics"),
    "Branch":              (r"io/branch/referral|BranchUniversalObject", "Analytics"),
    "Amplitude":           (r"com/amplitude/api|AmplitudeClient", "Analytics"),
    "Mixpanel":            (r"com/mixpanel/android|MixpanelAPI", "Analytics"),
    "OneSignal":           (r"com/onesignal|OneSignal", "Push"),
    "CleverTap":           (r"com/clevertap|CleverTapAPI", "Analytics"),
    "MoEngage":            (r"com/moengage|MoEngage", "Analytics"),
    "WebEngage":           (r"com/webengage|WebEngage", "Analytics"),
    "AppMetrica":          (r"com/yandex/metrica|AppMetrica", "Analytics"),
    "Sentry":              (r"io/sentry|SentryAndroid", "Crash"),
    "Bugsnag":             (r"com/bugsnag|Bugsnag", "Crash"),
    "New Relic":           (r"com/newrelic|NewRelic", "Monitoring"),
    "Datadog":             (r"com/datadog|Datadog", "Monitoring"),
    "Instabug":            (r"com/instabug|Instabug", "Crash"),
    "Stripe":              (r"com/stripe/android|Stripe", "Payments"),
    "Razorpay":            (r"com/razorpay|Razorpay", "Payments"),
    "PayPal":              (r"com/paypal|PayPal", "Payments"),
    "Braintree":           (r"com/braintreepayments|Braintree", "Payments"),
    "PhonePe":             (r"com/phonepe|PhonePe", "Payments"),
    "Paytm":               (r"com/paytm|Paytm", "Payments"),
    "Unity Ads":           (r"com/unity3d/ads|UnityAds", "Advertising"),
    "AppLovin":            (r"com/applovin|AppLovin", "Advertising"),
    "ironSource":          (r"com/ironsource|IronSource", "Advertising"),
    "Vungle":              (r"com/vungle|Vungle", "Advertising"),
    "AdColony":            (r"com/adcolony|AdColony", "Advertising"),
    "Chartboost":          (r"com/chartboost|Chartboost", "Advertising"),
    "InMobi":              (r"com/inmobi|InMobi", "Advertising"),
    "Mintegral":           (r"com/mintegral|Mintegral", "Advertising"),
    "Pangle":              (r"com/bytedance/sdk/openadsdk|Pangle", "Advertising"),
    "Amazon AWS SDK":      (r"com/amazonaws|AWSCredentials|AmazonS3", "Cloud"),
    "Azure SDK":           (r"com/microsoft/azure|com/azure", "Cloud"),
    "Supabase":            (r"io/supabase|SupabaseClient", "BaaS"),
    "Appwrite":            (r"io/appwrite|Appwrite", "BaaS"),
    "Parse":               (r"com/parse/Parse|ParseObject", "BaaS"),
    "Backendless":         (r"com/backendless|Backendless", "BaaS"),
    "MongoDB Realm":       (r"io/realm|RealmConfiguration", "Database"),
    "Twilio":              (r"com/twilio|Twilio", "Communication"),
    "SendGrid":            (r"com/sendgrid|SendGrid", "Communication"),
    "Agora":               (r"io/agora|AgoraRtcEngine", "Media"),
    "Jitsi":               (r"org/jitsi|JitsiMeet", "Media"),
    "Zoom SDK":            (r"us/zoom/sdk|ZoomSDK", "Media"),
    "Mapbox":              (r"com/mapbox|Mapbox", "Maps"),
    "Google Maps":         (r"com/google/android/gms/maps|SupportMapFragment", "Maps"),
    "HERE Maps":           (r"com/here/android|MapEngine", "Maps"),
    "OpenStreetMap":       (r"org/osmdroid|osmdroid", "Maps"),
    "ZXing (QR)":          (r"com/google/zxing|ZXing", "Utility"),
    "OkHttp":              (r"com/squareup/okhttp|OkHttpClient", "Network"),
    "Retrofit":            (r"retrofit2|Retrofit", "Network"),
    "Volley":              (r"com/android/volley|Volley", "Network"),
    "Glide":               (r"com/bumptech/glide|Glide", "Image"),
    "Picasso":             (r"com/squareup/picasso|Picasso", "Image"),
    "Coil":                (r"coil/|ImageLoader", "Image"),
    "Fresco":              (r"com/facebook/fresco|Fresco", "Image"),
    "Room DB":             (r"androidx/room|RoomDatabase", "Database"),
    "SQLCipher":           (r"net/sqlcipher|SQLiteDatabase", "Database"),
    "Realm DB":            (r"io/realm|Realm", "Database"),
    "Gson":                (r"com/google/gson|Gson", "Utility"),
    "Moshi":               (r"com/squareup/moshi|Moshi", "Utility"),
    "RxJava":              (r"io/reactivex|rx/", "Utility"),
    "Kotlin Coroutines":   (r"kotlinx/coroutines|CoroutineScope", "Utility"),
    "Dagger":              (r"dagger/|DaggerComponent", "DI"),
    "Hilt":                (r"dagger/hilt|HiltAndroidApp", "DI"),
    "Koin":                (r"org/koin|Koin", "DI"),
    "Flutter":             (r"io/flutter/|FlutterActivity|flutter_assets", "Framework"),
    "React Native":        (r"com/facebook/react|ReactNativeHost|index.android.bundle", "Framework"),
    "Cordova":             (r"org/apache/cordova|CordovaActivity", "Framework"),
    "Ionic Capacitor":     (r"com/getcapacitor|Capacitor", "Framework"),
    "Xamarin":             (r"mono/|Xamarin", "Framework"),
    "Unity Engine":        (r"com/unity3d/player|UnityPlayer", "Framework"),
    "Godot Engine":        (r"org/godotengine|Godot", "Framework"),
    "Expo":                (r"expo/modules|ExpoModules", "Framework"),
    "Jetpack Compose":     (r"androidx/compose|Composable", "UI"),
    "TensorFlow Lite":     (r"org/tensorflow/lite|Interpreter", "AI"),
    "ML Kit":              (r"com/google/mlkit|MlKit", "AI"),
    "OpenCV":              (r"org/opencv|OpenCVLoader", "AI"),
    "RootBeer":            (r"com/scottyab/rootbeer|RootBeer", "Security"),
    "SafetyNet":           (r"com/google/android/gms/safetynet|SafetyNet", "Security"),
    "Play Integrity":      (r"com/google/android/play/core/integrity|IntegrityManager", "Security"),
    "ProGuard":            (r"proguard|R8", "Build"),
}

SECRET_PATTERNS = {
    "Firebase API Key":     re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
    "Google OAuth Client":  re.compile(r"[0-9]{6,}-[0-9a-z]{32}\.apps\.googleusercontent\.com"),
    "Firebase DB URL":      re.compile(r"https://[a-z0-9\-]+\.firebaseio\.com"),
    "Firebase Storage URL": re.compile(r"https://firebasestorage\.googleapis\.com/v0/b/[a-z0-9\-]+\.appspot\.com"),
    "AWS Access Key":       re.compile(r"(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA)[A-Z0-9]{16}"),
    "GitHub Token":         re.compile(r"gh[pousr]_[A-Za-z0-9]{36,255}"),
    "Slack Token":          re.compile(r"xox[baprs]-[0-9A-Za-z\-]{10,}"),
    "Stripe Live Key":      re.compile(r"sk_live_[0-9a-zA-Z]{24,}"),
    "Razorpay Live Key":    re.compile(r"rzp_live_[0-9a-zA-Z]{14,}"),
    "Twilio SID":           re.compile(r"AC[a-f0-9]{32}"),
    "SendGrid Key":         re.compile(r"SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}"),
    "JWT":                  re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
    "Private Key (PEM)":    re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    "Mapbox Public Token":  re.compile(r"pk\.[A-Za-z0-9]{60,}"),
    "Algolia Search Key":   re.compile(r"(?i)algolia.{0,30}?['\"]([a-f0-9]{32})['\"]"),
}

FALSE_POSITIVE_SECRET_CONTEXT = re.compile(
    r"(?:example|sample|test|dummy|placeholder|your[_-]?key|xxxxx|aaaaa|"
    r"lorem|ipsum|changeme|replace[_-]?me|insert[_-]?key)",
    re.I
)

SUSPICIOUS_TERMS = re.compile(
    r"(?:/c2\b|/command\b|/cmd\b|/shell\b|/exec\b|/payload\b|/stage\b|/beacon\b|/bot\b|"
    r"/update\b|/download\b|/config\b|/gate\b|/panel\b|/loader\b|/install\b|/upload\b)",
    re.I
)

CODE_INDICATORS = {
    "DexClassLoader": re.compile(r"DexClassLoader", re.I),
    "PathClassLoader": re.compile(r"PathClassLoader", re.I),
    "InMemoryDexClassLoader": re.compile(r"InMemoryDexClassLoader", re.I),
    "ProcessBuilder": re.compile(r"ProcessBuilder", re.I),
    "Runtime.exec": re.compile(r"Runtime\s*\.\s*exec", re.I),
    "getDeviceId": re.compile(r"getDeviceId", re.I),
    "getSubscriberId": re.compile(r"getSubscriberId", re.I),
    "getSimSerialNumber": re.compile(r"getSimSerialNumber", re.I),
    "getImei": re.compile(r"getImei|getMeid", re.I),
    "WebView": re.compile(r"android\.webkit\.WebView|WebView", re.I),
    "JS Interface": re.compile(r"addJavascriptInterface", re.I),
    "REQUEST_INSTALL_PACKAGES": re.compile(r"REQUEST_INSTALL_PACKAGES", re.I),
    "AccessibilityService": re.compile(r"AccessibilityService|BIND_ACCESSIBILITY_SERVICE", re.I),
    "SmsManager": re.compile(r"SmsManager|sendTextMessage|sendMultipartTextMessage", re.I),
    "CallLog": re.compile(r"CallLog|content://call_log", re.I),
    "ContactsContract": re.compile(r"ContactsContract|content://contacts", re.I),
    "Camera API": re.compile(r"android\.hardware\.camera|Camera2|CameraManager", re.I),
    "AudioRecord": re.compile(r"AudioRecord|MediaRecorder", re.I),
    "ClipboardManager": re.compile(r"ClipboardManager|getPrimaryClip", re.I),
    "PackageInstaller": re.compile(r"PackageInstaller|PackageInstallerSession", re.I),
    "DevicePolicyManager": re.compile(r"DevicePolicyManager|DeviceAdminReceiver", re.I),
    "Reflection": re.compile(r"java\.lang\.reflect|Class\.forName|getDeclaredMethod", re.I),
    "Native lib loading": re.compile(r"System\.loadLibrary|loadLibrary\(", re.I),
    "Base64 decode": re.compile(r"android\.util\.Base64|Base64\.decode", re.I),
    "Crypto Cipher": re.compile(r"Cipher\.getInstance|SecretKeySpec|IvParameterSpec", re.I),
    "SQL raw query": re.compile(r"rawQuery|execSQL", re.I),
    "Root check": re.compile(r"/system/bin/su|/system/xbin/su|isRooted|RootBeer", re.I),
    "Emulator check": re.compile(r"ro\.kernel\.qemu|goldfish|generic_x86|isEmulator", re.I),
    "Debugger check": re.compile(r"isDebuggerConnected|android\.os\.Debug", re.I),
    "Screen capture": re.compile(r"MediaProjection|createScreenCaptureIntent", re.I),
    "Keylogger pattern": re.compile(r"onKeyDown|dispatchKeyEvent|KeyEvent", re.I),
    "Overlay attack": re.compile(r"TYPE_APPLICATION_OVERLAY|SYSTEM_ALERT_WINDOW", re.I),
    "Remote admin": re.compile(r"DeviceAdminReceiver|DevicePolicyManager", re.I),
    "URLConnection": re.compile(r"HttpURLConnection|openConnection", re.I),
}

DANGEROUS_PERMISSIONS = {
    "android.permission.READ_SMS":                  ("CRITICAL", "SMS पढ़ सकता है — OTP/2FA theft"),
    "android.permission.RECEIVE_SMS":               ("CRITICAL", "Incoming SMS intercept"),
    "android.permission.SEND_SMS":                  ("CRITICAL", "Premium-rate SMS fraud"),
    "android.permission.RECEIVE_MMS":               ("HIGH", "MMS intercept"),
    "android.permission.READ_CALL_LOG":             ("CRITICAL", "Call history theft"),
    "android.permission.WRITE_CALL_LOG":            ("HIGH", "Call log modify"),
    "android.permission.CALL_PHONE":                ("HIGH", "Unauthorized calls"),
    "android.permission.READ_CONTACTS":             ("HIGH", "Contacts theft"),
    "android.permission.WRITE_CONTACTS":            ("HIGH", "Contacts modify"),
    "android.permission.RECORD_AUDIO":              ("CRITICAL", "Microphone spying"),
    "android.permission.CAMERA":                    ("HIGH", "Camera access"),
    "android.permission.ACCESS_FINE_LOCATION":      ("HIGH", "Precise GPS tracking"),
    "android.permission.ACCESS_COARSE_LOCATION":    ("MEDIUM", "Approximate location"),
    "android.permission.ACCESS_BACKGROUND_LOCATION":("CRITICAL", "Background location"),
    "android.permission.REQUEST_INSTALL_PACKAGES":  ("CRITICAL", "Silent APK install"),
    "android.permission.SYSTEM_ALERT_WINDOW":       ("CRITICAL", "Overlay attack"),
    "android.permission.BIND_ACCESSIBILITY_SERVICE":("CRITICAL", "Accessibility abuse"),
    "android.permission.BIND_DEVICE_ADMIN":         ("CRITICAL", "Device admin"),
    "android.permission.READ_PHONE_STATE":          ("HIGH", "Device ID collection"),
    "android.permission.READ_PHONE_NUMBERS":        ("HIGH", "Phone number access"),
    "android.permission.PROCESS_OUTGOING_CALLS":    ("CRITICAL", "Call monitoring"),
    "android.permission.READ_EXTERNAL_STORAGE":     ("MEDIUM", "Files read"),
    "android.permission.WRITE_EXTERNAL_STORAGE":    ("MEDIUM", "Files write"),
    "android.permission.MANAGE_EXTERNAL_STORAGE":   ("CRITICAL", "Full file access"),
    "android.permission.QUERY_ALL_PACKAGES":        ("MEDIUM", "Installed apps list"),
    "android.permission.PACKAGE_USAGE_STATS":       ("HIGH", "App usage tracking"),
    "android.permission.POST_NOTIFICATIONS":        ("LOW", "Notifications"),
    "android.permission.INTERNET":                  ("LOW", "Network access"),
    "android.permission.ACCESS_NETWORK_STATE":      ("LOW", "Network state"),
    "android.permission.ACCESS_WIFI_STATE":         ("LOW", "WiFi state"),
    "android.permission.WAKE_LOCK":                 ("LOW", "Prevent sleep"),
    "android.permission.VIBRATE":                   ("LOW", "Vibration"),
    "android.permission.FOREGROUND_SERVICE":        ("MEDIUM", "Background service"),
    "android.permission.RECEIVE_BOOT_COMPLETED":    ("MEDIUM", "Auto-start on boot"),
    "android.permission.USE_BIOMETRIC":             ("MEDIUM", "Fingerprint"),
    "android.permission.USE_FINGERPRINT":           ("MEDIUM", "Fingerprint"),
    "android.permission.BLUETOOTH":                 ("LOW", "Bluetooth"),
    "android.permission.BLUETOOTH_ADMIN":           ("LOW", "Bluetooth admin"),
    "android.permission.BLUETOOTH_SCAN":            ("MEDIUM", "Bluetooth scan"),
    "android.permission.BLUETOOTH_CONNECT":         ("MEDIUM", "Bluetooth connect"),
}

LIBRARY_VERSION_PATTERNS = {
    "AppCompat":     r"androidx\.appcompat:appcompat:([\d.]+)",
    "Material":      r"com\.google\.android\.material:material:([\d.]+)",
    "Kotlin Stdlib": r"kotlin-stdlib-([\d.]+)\.jar",
    "OkHttp":        r"okhttp-([\d.]+)\.jar",
    "Retrofit":      r"retrofit-([\d.]+)\.jar",
    "Glide":         r"glide-([\d.]+)\.jar",
    "Room":          r"androidx\.room:room-runtime:([\d.]+)",
    "Coroutines":    r"kotlinx-coroutines-core-([\d.]+)\.jar",
    "Adjust":        r"adjust-android-([\d.]+)",
    "Firebase BOM":  r"firebase-bom:([\d.]+)",
    "Play Services": r"play-services-[a-z]+:([\d.]+)",
    "WorkManager":   r"androidx\.work:work-runtime:([\d.]+)",
    "Lifecycle":     r"androidx\.lifecycle:lifecycle-runtime:([\d.]+)",
    "Gson":          r"gson-([\d.]+)\.jar",
    "Moshi":         r"moshi-([\d.]+)\.jar",
    "Dagger":        r"dagger-([\d.]+)\.jar",
    "Hilt":          r"hilt-android-([\d.]+)",
    "Koin":          r"koin-android-([\d.]+)",
    "RxJava":        r"rxjava-([\d.]+)\.jar",
    "Guava":         r"guava-([\d.]+)\.jar",
    "Jetty":         r"jetty-([\d.]+)\.jar",
    "Conscrypt":     r"conscrypt-([\d.]+)",
    "BouncyCastle":  r"bcprov-jdk15on-([\d.]+)",
    "SQLCipher":     r"sqlcipher-android-([\d.]+)",
}

# ---------- OWASP Mobile Top 10 (2024) + MASVS ----------
OWASP_MOBILE_TOP10 = {
    "M1":  "Improper Credential Usage",
    "M2":  "Inadequate Supply Chain Security",
    "M3":  "Insecure Authentication/Authorization",
    "M4":  "Insufficient Input/Output Validation",
    "M5":  "Insecure Communication",
    "M6":  "Inadequate Privacy Controls",
    "M7":  "Insufficient Binary Protections",
    "M8":  "Security Misconfiguration",
    "M9":  "Insecure Data Storage",
    "M10": "Insufficient Cryptography",
}

WEAK_CRYPTO_PATTERNS = {
    "MD5":           re.compile(r'"MD5"|MessageDigest\.getInstance\("MD5"\)', re.I),
    "SHA-1":         re.compile(r'"SHA-?1"|MessageDigest\.getInstance\("SHA-?1"\)', re.I),
    "DES":           re.compile(r'"DES"|DESKeySpec|DESede', re.I),
    "AES/ECB":       re.compile(r'AES/ECB|"ECB"|Cipher\.getInstance\("AES/ECB', re.I),
    "RC4":           re.compile(r'"RC4"|ARC4', re.I),
    "Blowfish":      re.compile(r'"Blowfish"', re.I),
    "Hardcoded IV":  re.compile(r'IvParameterSpec\s*\(\s*"[^"]+"\s*\.\s*getBytes', re.I),
    "Hardcoded Key": re.compile(r'SecretKeySpec\s*\(\s*"[^"]{8,}"\s*\.\s*getBytes', re.I),
    "Weak Random":   re.compile(r'new\s+Random\s*\(\s*\)|Math\.random', re.I),
}

PRIVACY_APIS = {
    "Location tracking":    re.compile(r"getLastKnownLocation|requestLocationUpdates|FusedLocationProvider", re.I),
    "Contacts access":      re.compile(r"ContactsContract|content://contacts", re.I),
    "Call log access":      re.compile(r"CallLog|content://call_log", re.I),
    "SMS access":           re.compile(r"SmsManager|content://sms", re.I),
    "Camera access":        re.compile(r"android\.hardware\.camera|Camera2|CameraManager", re.I),
    "Microphone access":    re.compile(r"AudioRecord|MediaRecorder", re.I),
    "Clipboard access":     re.compile(r"ClipboardManager|getPrimaryClip", re.I),
    "Device identifiers":   re.compile(r"getDeviceId|getImei|getSubscriberId|getSimSerialNumber|ANDROID_ID", re.I),
    "Installed apps list":  re.compile(r"getInstalledPackages|getInstalledApplications|QUERY_ALL_PACKAGES", re.I),
    "Account info":         re.compile(r"AccountManager|getAccounts", re.I),
}

BINARY_PROTECTION_PATTERNS = {
    "Root detection":       re.compile(r"/system/bin/su|/system/xbin/su|isRooted|RootBeer|SafetyNet", re.I),
    "Emulator detection":   re.compile(r"ro\.kernel\.qemu|goldfish|generic_x86|isEmulator|Build\.FINGERPRINT", re.I),
    "Debugger detection":   re.compile(r"isDebuggerConnected|android\.os\.Debug|ptrace", re.I),
    "Tamper detection":     re.compile(r"checkSignature|verifySignature|GET_SIGNATURES", re.I),
    "Anti-hook":            re.compile(r"Xposed|frida|substrate", re.I),
    "Obfuscation present":  re.compile(r"proguard|R8|obfuscat", re.I),
}

FAKE_DOMAIN_PREFIXES = re.compile(
    r"^(?:"
    r"androidx\.|android\.|kotlin\.|kotlinx\.|java\.|javax\.|dalvik\.|"
    r"com\.google\.android\.material\.|com\.google\.android\.gms\.|"
    r"base\.|theme\.|widget\.|shapeappearance\.|textappearance\.|"
    r"materialalertdialog\.|platform\.|alertdialog\.|animation\.|cardview\.|"
    r"1base\.|11base\.|22|33|44|55|66|77|88|99"
    r")",
    re.I
)

FAKE_DOMAIN_TOKENS = re.compile(
    r"(?:theme|material|widget|shapeappearance|textappearance|appcompat|"
    r"alertdialog|animation|colorstate|builders|iterator|completion|"
    r"dispatcher|observer|coroutine|lifecycle|viewmodel)",
    re.I
)

VALID_TLDS = {
    "com","org","net","io","co","in","gov","edu","info","biz","app","dev",
    "xyz","me","us","uk","de","fr","jp","cn","ru","br","au","ca","tech",
    "online","site","store","ai","ml","cloud","live","link","page","space",
    "pro","mobi","tv","fm","gg","to","cc","ly","be","it","es","nl","se",
    "no","dk","fi","pl","cz","gr","pt","ch","at","ie","nz","za","mx","ar",
    "cl","pe","id","th","vn","ph","my","sg","kr","hk","tw","pk","bd","lk",
    "np","af","ir","iq","sa","ae","eg","ke","ng","gh","tz","ug","zw","su",
    "name","club","work","blog","shop","website","fun","world","today","news",
}

def is_real_domain(d):
    d = d.lower().rstrip(".")
    if len(d) < 4 or len(d) > 60:
        return False
    if d.count(".") > 4:
        return False
    if FAKE_DOMAIN_PREFIXES.match(d):
        return False
    if len(re.findall(r"[a-z]", d)) < 4:
        return False
    tld = d.rsplit(".", 1)[-1]
    if tld not in VALID_TLDS:
        return False
    if "_" in d:
        return False
    parts = d.split(".")
    if all(len(p) <= 1 for p in parts):
        return False
    if len(FAKE_DOMAIN_TOKENS.findall(d)) >= 2:
        return False
    return True

URL_RE = re.compile(r'(?i)\bhttps?://[^\s"\'<>\\]+')
IP_RE = re.compile(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?(?![\d.])')
EMAIL_RE = re.compile(r'(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{1,63}\b')
# High-confidence Indian mobile-number extraction.
# Bare 10-digit sequences are ignored unless explicit phone formatting or
# nearby phone-related context strongly supports that they are phone numbers.
PHONE_RE = re.compile(r'(?<![\d])(?:\+91[\s\-]?|0091[\s\-]?|91[\s\-])?([6-9]\d{9})(?![\d])')
PHONE_STRONG_RE = re.compile(r'(?<![\d])(?:\+91[\s\-]?|0091[\s\-]?|91[\s\-])([6-9]\d{9})(?![\d])')
PHONE_LABEL_CONTEXT = re.compile(
    r"\b(?:phone|mobile|mob|contact|tel|telephone|whatsapp|call|sms|customer.?care|support|helpline|number)\b|"
    r"\"phone\"|\"mobile\"|\"contact\"",
    re.I
)
PHONE_FP_CONTEXT = re.compile(
    r"\b(?:version|hash|sha|md5|size|timestamp|build|code|id|resource|array|addr|offset|length|buffer|random|"
    r"serial|transaction|order|invoice|account|userid|user_id|device|imei|imsi|iccid|lat|long|latitude|longitude)\b",
    re.I
)

def extract_high_confidence_phones(text):
    found = set()
    for m in PHONE_RE.finditer(text):
        raw = m.group(0)
        number = m.group(1)
        context = text[max(0, m.start()-70):min(len(text), m.end()+70)]
        strong_format = bool(PHONE_STRONG_RE.fullmatch(raw))
        labelled = bool(PHONE_LABEL_CONTEXT.search(context))
        bad_context = bool(PHONE_FP_CONTEXT.search(context))
        if strong_format or (labelled and not bad_context):
            found.add(number)
    return sorted(found)

DOMAIN_RE = re.compile(r'(?i)\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\b')

NON_DOMAIN_EXTENSIONS = {
    "php","java","kt","class","dex","so","apk","jar","aar","xml","json","txt","html","htm",
    "css","js","png","jpg","jpeg","gif","webp","ico","ttf","otf","woff","woff2","mp3","mp4",
    "wav","db","sqlite","properties","yml","yaml","md","pro","bin","dat","ini","cfg","conf",
    "gradle","zip","smali","kts","aidl","rs","proto","prof","profm","version","ktx"
}
NON_DOMAIN_WORDS = {
    "permission","permissions","activity","service","receiver","provider","intent","action",
    "extra","fragment","widget","annotation","internal","content","preference","savedstate",
    "dispatchers","coroutines","lifecycle"
}

def is_plausible_domain(d):
    d = d.lower().rstrip(".")
    parts = d.split(".")
    if len(parts) < 2:
        return False
    tld = parts[-1]
    if tld in NON_DOMAIN_EXTENSIONS:
        return False
    if any(p in NON_DOMAIN_WORDS for p in parts):
        return False
    if tld.isdigit():
        return False
    return True

def sha256_file(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()

def md5_file(p):
    h=hashlib.md5()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()

def read_apk_strings(apk):
    blobs=[]
    with zipfile.ZipFile(apk) as z:
        for n in z.namelist():
            try:
                data=z.read(n)
            except Exception:
                continue
            txt=data.decode("utf-8","ignore")
            blobs.append((n,txt))
            for m in re.finditer(rb"[\x20-\x7e]{5,}", data):
                try: blobs.append((n,m.group().decode("utf-8","ignore")))
                except Exception: pass
    return blobs

def parse_apk_certificate(apk):
    out = []
    try:
        with zipfile.ZipFile(apk) as z:
            names = [n for n in z.namelist() if n.upper().startswith("META-INF/")
                     and n.upper().endswith((".RSA",".DSA",".EC"))]
            for n in names:
                try:
                    der = z.read(n)
                except Exception:
                    continue
                info = {"entry": n, "sha256": hashlib.sha256(der).hexdigest()}
                try:
                    from cryptography import x509
                    from cryptography.hazmat.primitives import hashes
                    from cryptography.hazmat.primitives.serialization import pkcs7
                    certs = pkcs7.load_der_pkcs7_certificates(der)
                    if certs:
                        c = certs[0]
                        info.update({
                            "subject": c.subject.rfc4514_string(),
                            "issuer": c.issuer.rfc4514_string(),
                            "serial": hex(c.serial_number),
                            "not_before": c.not_valid_before_utc.isoformat() if hasattr(c, "not_valid_before_utc") else str(c.not_valid_before),
                            "not_after": c.not_valid_after_utc.isoformat() if hasattr(c, "not_valid_after_utc") else str(c.not_valid_after),
                            "signature_algorithm": c.signature_algorithm_oid._name,
                            "public_key_algorithm": c.public_key().__class__.__name__,
                            "self_signed": c.subject == c.issuer,
                            "sha256_fingerprint": c.fingerprint(hashes.SHA256()).hex(),
                        })
                except Exception as e:
                    info["parse_note"] = f"cryptography lib not available or parse error: {e}"
                out.append(info)
    except Exception:
        pass
    return out

def _axml_parse(data):
    try:
        if len(data) < 8: return None
        magic, size = struct.unpack_from("<II", data, 0)
        if magic != 0x00080003:
            return None
        sp_off = 8
        sp_type, sp_hdr_size, sp_size = struct.unpack_from("<HHI", data, sp_off)
        if sp_type != 0x0001: return None
        string_count, style_count, flags, strings_start, styles_start = struct.unpack_from("<IIIII", data, sp_off + 8)
        is_utf8 = (flags & (1 << 8)) != 0
        offsets = struct.unpack_from("<%dI" % string_count, data, sp_off + 28)
        base = sp_off + strings_start
        strings = []
        for off in offsets:
            p = base + off
            if is_utf8:
                u8 = data[p]; p += 1
                if u8 & 0x80: p += 1
                u16 = data[p]; p += 1
                if u16 & 0x80: p += 1
                end = data.index(b"\x00", p)
                strings.append(data[p:end].decode("utf-8", "ignore"))
            else:
                u16 = struct.unpack_from("<H", data, p)[0]; p += 2
                if u16 & 0x8000:
                    u16 = ((u16 & 0x7FFF) << 16) | struct.unpack_from("<H", data, p)[0]; p += 2
                end = p
                while end + 1 < len(data) and data[end:end+2] != b"\x00\x00":
                    end += 2
                strings.append(data[p:end].decode("utf-16-le", "ignore"))
        return strings
    except Exception:
        return None

def parse_manifest(apk):
    out = {"package": None, "version_name": None, "version_code": None,
           "permissions": [], "permissions_with_risk": [],
           "exported_activities": [], "exported_services": [],
           "exported_receivers": [], "exported_providers": [], "deep_links": [],
           "activities_count": 0, "services_count": 0, "receivers_count": 0, "providers_count": 0,
           "parse_note": None}
    try:
        with zipfile.ZipFile(apk) as z:
            raw = z.read("AndroidManifest.xml")
    except Exception as e:
        out["parse_note"] = f"manifest not found: {e}"
        return out
    strings = _axml_parse(raw)
    if not strings:
        out["parse_note"] = "binary AXML parse failed (may be text or obfuscated)"
        txt = raw.decode("utf-8","ignore")
        out["permissions"] = sorted(set(re.findall(r'android\.permission\.[A-Z0-9_]+', txt)))
    else:
        for i, s in enumerate(strings):
            if s.startswith("android.permission.") and s not in out["permissions"]:
                out["permissions"].append(s)
            if s.startswith("http://") or s.startswith("https://"):
                if s not in out["deep_links"]:
                    out["deep_links"].append(s)
            if s.startswith("package=") or (s.startswith("com.") and out["package"] is None and "." in s and "permission" not in s and len(s) < 80):
                out["package"] = s
        out["permissions"] = sorted(set(out["permissions"]))
        out["deep_links"] = sorted(set(out["deep_links"]))

    for p in out["permissions"]:
        risk, desc = DANGEROUS_PERMISSIONS.get(p, ("UNKNOWN", "Unknown risk"))
        out["permissions_with_risk"].append({"permission": p, "risk": risk, "desc": desc})
    risk_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    out["permissions_with_risk"].sort(key=lambda x: risk_order.get(x["risk"], 5))
    return out

def parse_dex(apk):
    out = {"dex_files": [], "classes": [], "method_count": 0, "class_count": 0,
           "interesting_classes": [], "notes": []}
    interesting_rx = re.compile(
        r"(?:admin|login|auth|token|secret|crypto|encrypt|decrypt|"
        r"payload|exploit|shell|root|sms|call|camera|mic|location|"
        r"contact|clipboard|accessibility|keylog|screen|record|"
        r"upload|download|remote|command|control)",
        re.I
    )
    try:
        with zipfile.ZipFile(apk) as z:
            dex_names = [n for n in z.namelist() if n.endswith(".dex")]
            for n in dex_names:
                try:
                    d = z.read(n)
                except Exception:
                    continue
                info = {"name": n, "size": len(d)}
                if len(d) >= 112:
                    magic = d[:8]
                    info["magic"] = magic.decode("ascii", "ignore")
                    if magic.startswith(b"dex\n"):
                        string_ids_size = struct.unpack_from("<I", d, 0x38)[0]
                        type_ids_size   = struct.unpack_from("<I", d, 0x40)[0]
                        proto_ids_size  = struct.unpack_from("<I", d, 0x48)[0]
                        field_ids_size  = struct.unpack_from("<I", d, 0x50)[0]
                        method_ids_size = struct.unpack_from("<I", d, 0x58)[0]
                        class_defs_size = struct.unpack_from("<I", d, 0x60)[0]
                        info.update({
                            "string_ids": string_ids_size,
                            "type_ids": type_ids_size,
                            "proto_ids": proto_ids_size,
                            "field_ids": field_ids_size,
                            "method_ids": method_ids_size,
                            "class_defs": class_defs_size,
                        })
                        out["method_count"] += method_ids_size
                        out["class_count"] += class_defs_size
                        classes = set(re.findall(rb"L[a-zA-Z0-9_/$]{3,200};", d))
                        for c in list(classes)[:5000]:
                            try:
                                cn = c.decode("ascii","ignore")
                                out["classes"].append(cn)
                                if interesting_rx.search(cn):
                                    out["interesting_classes"].append(cn)
                            except Exception:
                                pass
                out["dex_files"].append(info)
    except Exception as e:
        out["notes"].append(str(e))
    out["classes"] = sorted(set(out["classes"]))
    out["interesting_classes"] = sorted(set(out["interesting_classes"]))[:200]
    return out

def parse_native_libs(apk):
    libs = []
    try:
        with zipfile.ZipFile(apk) as z:
            for n in z.namelist():
                if n.startswith("lib/") and n.endswith(".so"):
                    try:
                        info = z.getinfo(n)
                        data = z.read(n)
                        arch = n.split("/")[1] if "/" in n else "unknown"
                        libs.append({
                            "path": n,
                            "size": info.file_size,
                            "arch": arch,
                            "sha256_short": hashlib.sha256(data).hexdigest()[:16],
                        })
                    except Exception:
                        continue
    except Exception:
        pass
    return libs

def parse_apk_structure(apk):
    struct = {"total_files": 0, "total_size": 0, "by_extension": {}, "by_folder": {},
              "dex_count": 0, "so_count": 0, "res_count": 0, "assets_count": 0}
    try:
        with zipfile.ZipFile(apk) as z:
            for info in z.infolist():
                struct["total_files"] += 1
                struct["total_size"] += info.file_size
                name = info.filename
                ext = name.rsplit(".", 1)[-1].lower() if "." in name else "(no ext)"
                struct["by_extension"][ext] = struct["by_extension"].get(ext, 0) + 1
                folder = name.split("/")[0] if "/" in name else "(root)"
                struct["by_folder"][folder] = struct["by_folder"].get(folder, 0) + 1
                if name.endswith(".dex"): struct["dex_count"] += 1
                if name.startswith("lib/") and name.endswith(".so"): struct["so_count"] += 1
                if name.startswith("res/"): struct["res_count"] += 1
                if name.startswith("assets/"): struct["assets_count"] += 1
    except Exception:
        pass
    struct["by_extension"] = dict(sorted(struct["by_extension"].items(), key=lambda x: -x[1])[:25])
    return struct

def find_embedded_payloads(apk):
    payloads = {"apk": [], "dex": [], "jar": [], "zip": [], "db": [],
                "elf": [], "other_bin": [], "html": [], "js": []}
    try:
        with zipfile.ZipFile(apk) as z:
            for n in z.namelist():
                nl = n.lower()
                try:
                    info = z.getinfo(n)
                except Exception:
                    continue
                if nl.endswith(".apk"): payloads["apk"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".dex"): payloads["dex"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".jar"): payloads["jar"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".zip"): payloads["zip"].append({"name": n, "size": info.file_size})
                elif nl.endswith((".db", ".sqlite", ".sqlite3")): payloads["db"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".so"): payloads["elf"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".html"): payloads["html"].append({"name": n, "size": info.file_size})
                elif nl.endswith(".js") and info.file_size > 5000: payloads["js"].append({"name": n, "size": info.file_size})
                elif nl.startswith("assets/") and "." not in nl.split("/")[-1] and info.file_size > 1000:
                    payloads["other_bin"].append({"name": n, "size": info.file_size})
    except Exception:
        pass
    return payloads

def extract_library_versions(apk):
    versions = {}
    try:
        with zipfile.ZipFile(apk) as z:
            for name in z.namelist():
                if not (name.endswith(".properties") or name.endswith(".version")
                        or name.endswith(".xml") or name.endswith(".json")
                        or name.endswith(".txt") or name.startswith("META-INF/")):
                    continue
                try:
                    txt = z.read(name).decode("utf-8", "ignore")
                except Exception:
                    continue
                for lib, pat in LIBRARY_VERSION_PATTERNS.items():
                    for m in re.finditer(pat, txt):
                        versions.setdefault(lib, set()).add(m.group(1))
    except Exception:
        pass
    return {k: sorted(v) for k, v in versions.items()}

# ---------- Legal / correspondence contacts for identified infrastructure providers ----------
# Maps a PROVIDERS entry (or a group of related entries, matched by prefix below) to the
# company that operates it and where investigators send a preservation letter / subpoena /
# MLAT request to obtain account subscriber info (who registered the project/bucket/number,
# registration IP, billing details, etc). These are public, official company pages -- this
# tool never contacts them automatically; it only points the investigator to the right place.
LEGAL_CORRESPONDENCE = {
    "Google":     {"company": "Google LLC", "contact_url": "https://lers.google.com/",
                   "note": "Google's Law Enforcement Request System (LERS). Covers Firebase, "
                           "Google Cloud, Play, Analytics. Request project owner / registration "
                           "IP / billing info for the identified project."},
    "Amazon":     {"company": "Amazon / AWS", "contact_url": "https://aws.amazon.com/compliance/amazon-information-requests/",
                   "note": "AWS Information Requests page. Covers S3, API Gateway, CloudFront, "
                           "Cognito, DynamoDB, Lambda, Amplify. Preservation letters go through this channel."},
    "Microsoft":  {"company": "Microsoft Corporation", "contact_url": "https://www.microsoft.com/en-us/corporate-responsibility/law-enforcement-requests-report",
                   "note": "Covers Azure Web Apps/Blob/SQL/CDN, Microsoft Graph. Submit legal "
                           "process through Microsoft's Global Criminal Compliance team."},
    "Cloudflare": {"company": "Cloudflare, Inc.", "contact_url": "https://www.cloudflare.com/trust-hub/law-enforcement/",
                   "note": "Cloudflare is usually only a reverse proxy/CDN in front of the real "
                           "origin server -- request origin IP logs, not just the customer identity."},
    "Meta":       {"company": "Meta Platforms, Inc. (Facebook/WhatsApp)", "contact_url": "https://www.facebook.com/records/login/",
                   "note": "Meta's Law Enforcement Online Requests portal. Covers Facebook, "
                           "WhatsApp, Instagram infrastructure."},
    "Telegram":   {"company": "Telegram FZ-LLC", "contact_url": "https://telegram.org/faq#q-i-have-a-legal-question",
                   "note": "Telegram publishes very limited data and historically has a narrow "
                           "cooperation policy; still worth a formal request for the record."},
    "Twilio":     {"company": "Twilio Inc.", "contact_url": "https://www.twilio.com/en-us/legal/law-enforcement-guidelines",
                   "note": "Twilio's Law Enforcement Guidelines page covers SMS/voice API abuse "
                           "requests (e.g. spoofed OTP/SMS infrastructure)."},
    "Sentry":     {"company": "Functional Software, Inc. (Sentry)", "contact_url": "https://sentry.io/legal/",
                   "note": "Crash-reporting SDK; account holder info may reveal developer identity."},
    "OneSignal":  {"company": "OneSignal, Inc.", "contact_url": "https://onesignal.com/legal",
                   "note": "Push-notification SDK; account holder info may reveal developer identity."},
    "Stripe":     {"company": "Stripe, Inc.", "contact_url": "https://stripe.com/legal/law-enforcement-guide",
                   "note": "Stripe's Law Enforcement Guide covers payment account subscriber info."},
    "Razorpay":   {"company": "Razorpay Software Pvt Ltd (India)", "contact_url": "https://razorpay.com/support/",
                   "note": "Indian payment gateway -- reachable via standard Indian LEA process "
                           "(CrPC Section 91 notice / MHA cybercrime portal coordination)."},
    "PhonePe":    {"company": "PhonePe Pvt Ltd (India)", "contact_url": "https://www.phonepe.com/support/",
                   "note": "Indian payment app -- reachable via standard Indian LEA process."},
    "Paytm":      {"company": "One97 Communications (Paytm, India)", "contact_url": "https://paytm.com/care",
                   "note": "Indian payment app -- reachable via standard Indian LEA process."},
    "Supabase":   {"company": "Supabase, Inc.", "contact_url": "https://supabase.com/legal",
                   "note": "BaaS provider; account holder info may reveal developer identity."},
    "Vercel":     {"company": "Vercel Inc.", "contact_url": "https://vercel.com/legal/law-enforcement",
                   "note": "Hosting provider; account holder info may reveal developer identity."},
    "Netlify":    {"company": "Netlify, Inc.", "contact_url": "https://www.netlify.com/legal/",
                   "note": "Hosting provider; account holder info may reveal developer identity."},
    "DigitalOcean": {"company": "DigitalOcean, LLC", "contact_url": "https://www.digitalocean.com/legal/law-enforcement-requests",
                     "note": "Cloud/VPS provider; can identify the droplet/account owner."},
    "GitHub":     {"company": "GitHub, Inc. (Microsoft)", "contact_url": "https://docs.github.com/en/site-policy/other-site-policies/github-law-enforcement-guidelines",
                   "note": "If source/config repos are referenced, GitHub can identify the account holder."},
    "Sendgrid":   {"company": "Twilio SendGrid", "contact_url": "https://www.twilio.com/en-us/legal/law-enforcement-guidelines",
                   "note": "Email delivery infrastructure; owned by Twilio."},
}

# Prefix rules: any PROVIDERS entry whose name starts with the key text maps to the same
# correspondence contact as its parent company.
LEGAL_CORRESPONDENCE_PREFIXES = [
    ("Firebase", "Google"), ("Google", "Google"),
    ("AWS", "Amazon"),
    ("Azure", "Microsoft"), ("Microsoft", "Microsoft"),
    ("Cloudflare", "Cloudflare"),
    ("Facebook", "Meta"), ("WhatsApp", "Meta"),
    ("Telegram", "Telegram"),
    ("Twilio", "Twilio"),
    ("Sentry", "Sentry"),
    ("OneSignal", "OneSignal"),
    ("Stripe", "Stripe"),
    ("Razorpay", "Razorpay"),
    ("PhonePe", "PhonePe"),
    ("Paytm", "Paytm"),
    ("Supabase", "Supabase"),
    ("Vercel", "Vercel"),
    ("Netlify", "Netlify"),
    ("DigitalOcean", "DigitalOcean"),
    ("SendGrid", "Sendgrid"),
]

def legal_contact_for(provider):
    """Return {'company','contact_url','note'} for a PROVIDERS name, or None if this
    tool doesn't have a curated official contact for it (investigator should search the
    company's own 'law enforcement requests' / 'legal' / 'trust & safety' page)."""
    if not provider or provider == "Unknown":
        return None
    for prefix, key in LEGAL_CORRESPONDENCE_PREFIXES:
        if provider.startswith(prefix):
            return LEGAL_CORRESPONDENCE.get(key)
    return LEGAL_CORRESPONDENCE.get(provider)

def build_legal_correspondence(network):
    """One highlighted row per unique (provider) actually found in this APK's network
    indicators, so an investigator can see at a glance who to send correspondence to."""
    seen = {}
    for x in network:
        provider = x.get("provider", "")
        if not provider or provider == "Unknown":
            continue
        if provider in seen:
            seen[provider]["urls"].append(x["url"])
            continue
        contact = legal_contact_for(provider)
        seen[provider] = {
            "provider": provider,
            "urls": [x["url"]],
            "company": contact["company"] if contact else None,
            "contact_url": contact["contact_url"] if contact else None,
            "note": contact["note"] if contact else
                    "No curated official contact on file for this provider -- search the "
                    "company's own 'law enforcement requests' / legal / trust & safety page.",
            "has_curated_contact": contact is not None,
        }
    # curated-contact entries first (most actionable), then the rest
    return sorted(seen.values(), key=lambda e: (not e["has_curated_contact"], e["provider"]))

ENDPOINT_INTELLIGENCE = {
    "Firebase Realtime DB": ("DATABASE", "Potential Firebase Realtime Database endpoint; review project/database path and authorization rules."),
    "Firebase Storage": ("STORAGE", "Potential Firebase Storage endpoint; review bucket/object paths and access controls."),
    "Firebase Auth": ("AUTH", "Firebase Authentication infrastructure endpoint detected."),
    "Firebase Cloud Messaging": ("PUSH", "Firebase push-notification infrastructure detected."),
    "Firebase Remote Config": ("CONFIG", "Remote configuration endpoint detected; review referenced configuration during deeper analysis."),
    "AWS S3": ("STORAGE", "Potential Amazon S3 object-storage endpoint; review bucket/object path and access policy."),
    "AWS API Gateway": ("API", "Potential AWS API Gateway backend endpoint; useful for identifying application API infrastructure."),
    "AWS Cognito": ("AUTH", "AWS Cognito identity/authentication infrastructure detected."),
    "AWS DynamoDB": ("DATABASE", "Potential DynamoDB backend infrastructure detected."),
    "AWS Lambda": ("SERVERLESS", "Potential AWS Lambda serverless backend endpoint detected."),
    "Azure Blob": ("STORAGE", "Potential Azure Blob Storage endpoint detected."),
    "Azure SQL": ("DATABASE", "Potential Azure SQL infrastructure endpoint detected."),
    "Microsoft Graph": ("API", "Microsoft Graph API endpoint detected."),
    "Supabase": ("DATABASE/API", "Supabase project/API endpoint detected; review REST paths and RLS configuration."),
    "MongoDB Atlas": ("DATABASE", "MongoDB Atlas infrastructure endpoint detected."),
    "Appwrite": ("BACKEND", "Appwrite backend endpoint detected."),
    "Back4App / Parse": ("BACKEND", "Parse/Back4App backend endpoint detected."),
    "Backendless": ("BACKEND", "Backendless backend endpoint detected."),
    "Cloudflare R2": ("STORAGE", "Potential Cloudflare R2 object-storage endpoint detected."),
    "Cloudflare Workers": ("SERVERLESS", "Potential Cloudflare Workers backend endpoint detected."),
    "Google Cloud": ("CLOUD", "Google Cloud-hosted backend endpoint detected."),
}

def build_endpoint_intelligence(network):
    out=[]
    for x in network:
        provider=x.get("provider", "")
        if provider in ENDPOINT_INTELLIGENCE:
            kind, note=ENDPOINT_INTELLIGENCE[provider]
            out.append({"url":x.get("url"),"domain":x.get("domain"),"provider":provider,
                        "endpoint_type":kind,"investigative_value":note,
                        "classification":x.get("classification")})
    return out

def check_cloud_misconfig(secrets, urls, alltext):
    alerts = []
    firebase_key = None
    firebase_urls = set()
    supabase_url = None
    supabase_key = None
    for s in secrets:
        if s["type"] == "Firebase API Key": firebase_key = s["value"]
        if s["type"] == "Firebase DB URL": firebase_urls.add(s["value"])
    for m in re.finditer(r"https://[a-z0-9\-]+\.firebaseio\.com", alltext):
        firebase_urls.add(m.group(0))
    for m in re.finditer(r"https://[a-z0-9]+\.supabase\.co", alltext):
        supabase_url = m.group(0)
    for m in re.finditer(r"eyJ[A-Za-z0-9_\-]{20,}\.eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}", alltext):
        supabase_key = m.group(0); break
    if firebase_key and firebase_urls:
        for u in firebase_urls:
            alerts.append({
                "severity": "HIGH",
                "title": "Firebase Realtime Database configuration detected — access rules require verification",
                "detail": "Firebase URL + API key दोनों मिले। अगर rules public हैं तो DB कोई भी पढ़ सकता है।",
                "test_url": u.rstrip("/") + "/.json",
                "key": firebase_key,
                "fix": "Firebase Console → Realtime Database → Rules में auth require करें",
            })
    if supabase_url and supabase_key:
        alerts.append({
            "severity": "MEDIUM",
            "title": "Supabase project detected",
            "detail": "Supabase URL + JWT key मिले। Row-Level Security (RLS) verify करें।",
            "test_url": supabase_url + "/rest/v1/",
            "key": supabase_key[:40] + "...",
            "fix": "Supabase Dashboard → Auth → RLS policies enable करें",
        })
    return alerts

# ===== OWASP Mobile Top 10 (2024) + MASVS analysis =====
def owasp_analyze(d):
    findings = []
    alltext = d.get("alltext", "")
    secrets = d.get("secrets", []) or []
    network = d.get("network", []) or []
    urls = d.get("urls", []) or []
    indicators = d.get("indicators", []) or []
    manifest = d.get("manifest", {}) or {}
    permissions = d.get("permissions", []) or []
    cert = d.get("certificates", []) or []
    native_libs = d.get("native_libs", []) or []
    dex = d.get("dex", {}) or {}
    versions = d.get("library_versions", {}) or {}

    def add(oid, sev, title, evidence, masvs):
        findings.append({
            "id": oid,
            "category": OWASP_MOBILE_TOP10.get(oid, oid),
            "severity": sev,
            "title": title,
            "evidence": evidence,
            "masvs": masvs,
        })

    # M1: Improper Credential Usage
    cred_types = {"Firebase API Key","Google OAuth Client","AWS Access Key","Stripe Live Key",
                  "Razorpay Live Key","Twilio SID","SendGrid Key","Slack Token","GitHub Token",
                  "Private Key (PEM)","Mapbox Public Token"}
    found_creds = [s for s in secrets if s["type"] in cred_types]
    if found_creds:
        sev = "CRITICAL" if any(s["type"] in ("Private Key (PEM)","AWS Access Key") for s in found_creds) else "HIGH"
        add("M1", sev,
            f"{len(found_creds)} hardcoded credential(s) found in APK",
            ", ".join(sorted({s['type'] for s in found_creds})),
            "MASVS-AUTH, MASVS-STORAGE")
    if any(s["type"] == "Private Key (PEM)" for s in secrets):
        add("M1", "CRITICAL",
            "Private key (PEM) embedded in APK",
            "Attacker can extract and impersonate the app",
            "MASVS-CRYPTO, MASVS-STORAGE")

    # M2: Inadequate Supply Chain Security
    for c in cert:
        if c.get("self_signed"):
            add("M2", "HIGH",
                "APK signed with self-signed certificate",
                f"Subject: {c.get('subject','?')[:80]}",
                "MASVS-CODE")
            break
    outdated = []
    if "OkHttp" in versions:
        for v in versions["OkHttp"]:
            try:
                if int(v.split(".")[0]) < 4: outdated.append(f"OkHttp {v}")
            except Exception: pass
    if "Guava" in versions:
        for v in versions["Guava"]:
            try:
                if int(v.split(".")[0]) < 32: outdated.append(f"Guava {v}")
            except Exception: pass
    if outdated:
        add("M2", "MEDIUM",
            "Outdated third-party libraries detected",
            ", ".join(outdated),
            "MASVS-CODE")

    # M3: Insecure Authentication/Authorization
    if re.search(r'MODE_WORLD_READABLE|MODE_WORLD_WRITEABLE', alltext, re.I):
        add("M3", "HIGH",
            "World-readable/writable SharedPreferences",
            "MODE_WORLD_READABLE or MODE_WORLD_WRITEABLE used",
            "MASVS-STORAGE, MASVS-AUTH")
    if "exported=\"true\"" in alltext or "exported=true" in alltext.lower():
        add("M3", "MEDIUM",
            "Exported components present",
            "Activities/services/receivers may be reachable from other apps",
            "MASVS-PLATFORM")

    # M4: Insufficient Input/Output Validation
    if "JS Interface" in indicators:
        add("M4", "HIGH",
            "WebView with JavaScript interface exposed",
            "addJavascriptInterface() — RCE risk on old Android (<4.2)",
            "MASVS-PLATFORM, MASVS-CODE")
    if "SQL raw query" in indicators:
        add("M4", "MEDIUM",
            "Raw SQL query usage detected",
            "rawQuery()/execSQL() — potential SQL injection",
            "MASVS-CODE")
    if "Reflection" in indicators:
        add("M4", "LOW",
            "Java reflection usage detected",
            "May hide runtime behavior, harder to analyze",
            "MASVS-CODE")

    # M5: Insecure Communication
    http_urls = [x for x in network if x.get("classification","").startswith("Potentially risky HTTP")]
    c2_http = [x for x in network if "over HTTP" in x.get("classification","")]
    if http_urls or c2_http:
        total = len(http_urls) + len(c2_http)
        sample = "; ".join(x["url"] for x in (http_urls + c2_http)[:3])
        add("M5", "HIGH" if c2_http else "MEDIUM",
            f"{total} HTTP (plaintext) endpoint(s) detected",
            sample,
            "MASVS-NETWORK")
    if not re.search(r'CertificatePinner|X509TrustManager|network_security_config', alltext, re.I):
        add("M5", "LOW",
            "Certificate pinning indicators were not identified during static triage",
            "MITM risk if system CA is compromised",
            "MASVS-NETWORK")

    # M6: Inadequate Privacy Controls
    privacy_hits = [name for name, rx in PRIVACY_APIS.items() if rx.search(alltext)]
    if privacy_hits:
        add("M6", "MEDIUM" if len(privacy_hits) < 4 else "HIGH",
            f"{len(privacy_hits)} privacy-sensitive API(s) used",
            ", ".join(privacy_hits),
            "MASVS-PRIVACY")
    privacy_perms = [p for p in permissions if any(k in p for k in (
        "LOCATION","CAMERA","RECORD_AUDIO","READ_CONTACTS","READ_SMS","CALL_LOG","PHONE_STATE"))]
    if privacy_perms:
        add("M6", "MEDIUM",
            f"{len(privacy_perms)} privacy-related permission(s) requested",
            ", ".join(p.split(".")[-1] for p in privacy_perms[:5]),
            "MASVS-PRIVACY")

    # M7: Insufficient Binary Protections
    protection_missing = []
    for name, rx in BINARY_PROTECTION_PATTERNS.items():
        if not rx.search(alltext):
            if name in ("Root detection","Emulator detection","Debugger detection","Tamper detection"):
                protection_missing.append(name)
    if protection_missing:
        add("M7", "MEDIUM",
            f"Missing {len(protection_missing)} binary protection(s)",
            ", ".join(protection_missing),
            "MASVS-RESILIENCE")
    if not native_libs:
        add("M7", "LOW",
            "No native (.so) libraries were found inside the analyzed APK",
            "Easier to decompile with jadx",
            "MASVS-RESILIENCE")

    # M8: Security Misconfiguration
    if re.search(r'android:debuggable\s*=\s*"true"', alltext, re.I) or "debuggable=true" in alltext.lower():
        add("M8", "HIGH",
            "Application is debuggable",
            "android:debuggable=\"true\" — anyone can attach debugger",
            "MASVS-CODE, MASVS-PLATFORM")
    if re.search(r'android:allowBackup\s*=\s*"true"', alltext, re.I):
        add("M8", "MEDIUM",
            "App data backup allowed",
            "android:allowBackup=\"true\" — data extractable via ADB",
            "MASVS-STORAGE")
    if re.search(r'android:usesCleartextTraffic\s*=\s*"true"', alltext, re.I) or "usescleartexttraffic" in alltext.lower():
        add("M8", "HIGH",
            "Cleartext traffic allowed",
            "android:usesCleartextTraffic=\"true\"",
            "MASVS-NETWORK")
    if re.search(r'android:networkSecurityConfig', alltext, re.I) is None:
        add("M8", "LOW",
            "No network security config",
            "Not using network_security_config.xml",
            "MASVS-NETWORK")

    # M9: Insecure Data Storage
    if re.search(r'getExternalStorageDirectory|getExternalFilesDir|Environment\.getExternal', alltext, re.I):
        add("M9", "MEDIUM",
            "Data written to external storage",
            "getExternalFilesDir() / getExternalStorageDirectory() — world-readable on old Android",
            "MASVS-STORAGE")
    if re.search(r'openOrCreateDatabase|SQLiteDatabase\.openDatabase', alltext, re.I) and "SQLCipher" not in str(versions) and not re.search(r'net/sqlcipher', alltext, re.I):
        add("M9", "MEDIUM",
            "Unencrypted SQLite database usage",
            "SQLite without SQLCipher — data readable if device rooted",
            "MASVS-STORAGE, MASVS-CRYPTO")
    if re.search(r'SharedPreferences', alltext, re.I):
        add("M9", "LOW",
            "SharedPreferences usage detected",
            "Sensitive data should use EncryptedSharedPreferences",
            "MASVS-STORAGE")

    # M10: Insufficient Cryptography
    weak_found = [name for name, rx in WEAK_CRYPTO_PATTERNS.items() if rx.search(alltext)]
    if weak_found:
        sev = "HIGH" if any(x in weak_found for x in ("MD5","SHA-1","DES","AES/ECB","Hardcoded IV","Hardcoded Key")) else "MEDIUM"
        add("M10", sev,
            f"Weak cryptography detected ({len(weak_found)})",
            ", ".join(weak_found),
            "MASVS-CRYPTO")

    # Sort by severity
    sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    findings.sort(key=lambda x: (sev_order.get(x["severity"], 5), x["id"]))

    summary = {
        "total": len(findings),
        "by_severity": {},
        "by_id": {},
        "masvs_covered": sorted({m for f in findings for m in f["masvs"].split(", ")}),
    }
    for f in findings:
        summary["by_severity"][f["severity"]] = summary["by_severity"].get(f["severity"], 0) + 1
        summary["by_id"].setdefault(f["id"], 0)
        summary["by_id"][f["id"]] += 1

    return {"findings": findings, "summary": summary}

EXCLUDE_URL_PATTERNS = [
    r"schemas\.android\.com", r"apache\.org/licenses", r"mozilla\.org/MPL",
    r"w3\.org", r"json\.org", r"example\.com",
    r"developer\.android\.com/training", r"issuetracker\.google\.com",
    r"youtrack\.jetbrains\.com", r"publicsuffix\.org", r"ietf\.org",
    r"opensource\.org/licenses", r"gnu\.org/licenses",
    r"creativecommons\.org", r"eclipse\.org/legal",
    r"\.googleapis\.com/auth", r"accounts\.google\.com/o/oauth2",
]

def extract_clean_urls(alltext):
    url_pattern = re.compile(r'https?://[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}(?:/[^\s"\'<>\\]*)?')
    raw_urls = url_pattern.findall(alltext)
    clean = []
    for u in raw_urls:
        u = u.rstrip(").,;]")
        if any(re.search(p, u, re.I) for p in EXCLUDE_URL_PATTERNS):
            continue
        if len(u) > 300:
            continue
        clean.append(u)
    return sorted(set(clean))

def classify_domain(d):
    d=d.lower().rstrip(".")
    base=d[4:] if d.startswith("www.") else d
    for provider, pats in PROVIDERS:
        for pat in pats:
            if re.search(pat, base):
                return provider, "Third-party infrastructure/SDK", "Library/Service"
    if any(base == x or base.endswith("." + x) for x in LIBRARY_DOMAINS):
        return "Library/Documentation", "Reference/SDK", "Library URL"
    return "Unknown", "Custom/unknown infrastructure", "Investigate"

def endpoint_class(url, provider, typ):
    parsed=urllib.parse.urlparse(url)
    is_http = parsed.scheme == "http"
    if typ == "Library URL":
        return "Library URL"
    if SUSPICIOUS_TERMS.search(parsed.path or ""):
        return "Potential C2-like / control endpoint over HTTP" if is_http else "Potential C2-like / control endpoint"
    if is_http:
        return "Potentially risky HTTP"
    if provider not in ("Unknown",):
        return "Third-party service/SDK"
    return "Actual App Endpoint / Investigate"

def extract(apk):
    strings=read_apk_strings(apk)
    alltext="\n".join(t for _,t in strings)

    urls = extract_clean_urls(alltext)
    ips=sorted(set(IP_RE.findall(alltext)))
    emails=sorted(set(EMAIL_RE.findall(alltext)))

    phones = extract_high_confidence_phones(alltext)

    domains=set()
    for u in urls:
        try:
            h=urllib.parse.urlparse(u).hostname
            if h: domains.add(h.lower())
        except: pass
    for d in DOMAIN_RE.findall(alltext):
        dl = d.lower()
        if dl.startswith(("schemas.", "www.example.")):
            continue
        if not is_plausible_domain(dl):
            continue
        if not is_real_domain(dl):
            continue
        domains.add(dl)

    permissions=sorted(set(re.findall(r'android\.permission\.[A-Z0-9_]+', alltext)))

    indicators=[]
    for name, rx in CODE_INDICATORS.items():
        if rx.search(alltext): indicators.append(name)

    sdk_hits = []
    for sdk, (rx, cat) in SDK_SIGNATURES.items():
        if re.search(rx, alltext, re.I):
            sdk_hits.append({"sdk": sdk, "category": cat})
    seen_sdk = set()
    sdk_hits = [s for s in sdk_hits if not (s["sdk"] in seen_sdk or seen_sdk.add(s["sdk"]))]

    secrets = []
    for name, rx in SECRET_PATTERNS.items():
        for m in rx.finditer(alltext):
            ctx = alltext[max(0, m.start()-60):m.end()+60]
            if FALSE_POSITIVE_SECRET_CONTEXT.search(ctx):
                continue
            val = m.group(0)
            secrets.append({
                "type": name,
                "value": val[:120] + ("…" if len(val) > 120 else ""),
                "context": ctx.replace("\n", " ")[:160],
            })
    seen = set(); uniq = []
    for s in secrets:
        if s["value"] in seen: continue
        seen.add(s["value"]); uniq.append(s)
    secrets = uniq

    embedded_apks=[]
    try:
        with zipfile.ZipFile(apk) as z:
            embedded_apks=[n for n in z.namelist() if n.lower().endswith(".apk")]
    except: pass

    net=[]
    for u in urls:
        try:
            h=urllib.parse.urlparse(u).hostname or ""
        except: h=""
        provider,ptype,baseclass=classify_domain(h)
        cls=endpoint_class(u,provider,baseclass)
        net.append({"url":u,"domain":h,"provider":provider,"type":ptype,"classification":cls})

    cert = parse_apk_certificate(apk)
    manifest = parse_manifest(apk)
    dex = parse_dex(apk)
    native_libs = parse_native_libs(apk)
    structure = parse_apk_structure(apk)
    payloads = find_embedded_payloads(apk)
    versions = extract_library_versions(apk)
    cloud_alerts = check_cloud_misconfig(secrets, urls, alltext)

    owasp = owasp_analyze({
        "alltext": alltext,
        "secrets": secrets,
        "network": net,
        "urls": urls,
        "indicators": indicators,
        "manifest": manifest,
        "permissions": permissions,
        "certificates": cert,
        "native_libs": native_libs,
        "dex": dex,
        "library_versions": versions,
    })

    return {
        "alltext": alltext,
        "urls": urls,
        "domains": sorted(domains),
        "ips": ips,
        "emails": emails,
        "phones": phones,
        "permissions": permissions,
        "indicators": indicators,
        "embedded_apks": embedded_apks,
        "network": net,
        "sdks": sdk_hits,
        "secrets": secrets,
        "certificates": cert,
        "manifest": manifest,
        "dex": dex,
        "native_libs": native_libs,
        "structure": structure,
        "payloads": payloads,
        "library_versions": versions,
        "cloud_alerts": cloud_alerts,
        "owasp": owasp,
    }

def yara_scan(apk):
    try:
        import yara
    except Exception:
        return {"available":False,"matches":[],"message":"yara-python not installed; YARA scan skipped."}
    rules_dir=Path(__file__).with_name("rules")
    files=[str(x) for x in rules_dir.glob("*.yar")]
    if not files: return {"available":True,"matches":[],"message":"No YARA rule files found."}
    try:
        compiled=yara.compile(filepaths={Path(f).stem:f for f in files})
        matches=compiled.match(str(apk))
        out=[]
        for m in matches:
            out.append({"rule":m.rule,"namespace":m.namespace,"tags":list(m.tags)})
        return {"available":True,"matches":out,"message":""}
    except Exception as e:
        return {"available":True,"matches":[],"message":f"YARA error: {e}"}

def vt_hash_lookup(sha, api_key):
    if not api_key: return {"status":"not_configured"}
    try:
        import requests
        r=requests.get(f"https://www.virustotal.com/api/v3/files/{sha}",headers={"x-apikey":api_key},timeout=20)
        if r.status_code==200:
            a=r.json().get("data",{}).get("attributes",{})
            return {"status":"found","url":f"https://www.virustotal.com/gui/file/{sha}","stats":a.get("last_analysis_stats",{}),"first_submission":a.get("first_submission_date"),"last_analysis":a.get("last_analysis_date")}
        return {"status":"not_found" if r.status_code==404 else f"http_{r.status_code}","url":f"https://www.virustotal.com/gui/file/{sha}"}
    except Exception as e: return {"status":"error","message":str(e),"url":f"https://www.virustotal.com/gui/file/{sha}"}

def abuseipdb_lookup(ip, api_key):
    if not api_key: return {"status":"not_configured"}
    try:
        import requests
        r=requests.get("https://api.abuseipdb.com/api/v2/check",
                        params={"ipAddress":ip,"maxAgeInDays":"90"},
                        headers={"Key":api_key,"Accept":"application/json"}, timeout=15)
        if r.status_code==200:
            d=r.json().get("data",{})
            return {"status":"found","url":f"https://www.abuseipdb.com/check/{ip}",
                    "abuseConfidenceScore":d.get("abuseConfidenceScore"),
                    "countryCode":d.get("countryCode"),"isp":d.get("isp"),
                    "domain":d.get("domain"),"totalReports":d.get("totalReports"),
                    "isPublic":d.get("isPublic")}
        return {"status":f"http_{r.status_code}","url":f"https://www.abuseipdb.com/check/{ip}"}
    except Exception as e:
        return {"status":"error","message":str(e),"url":f"https://www.abuseipdb.com/check/{ip}"}

def score(indicators, net, yara, abuse=None, secrets=None, cert=None, cloud_alerts=None,
          manifest=None, payloads=None, owasp=None):
    """Evidence-weighted triage score. OWASP findings are descriptive and are
    intentionally NOT added a second time when their underlying evidence is
    already represented by indicators/permissions/secrets.
    """
    score = 0
    reasons = []
    weights = {"DexClassLoader":3,"ProcessBuilder":2,"Runtime.exec":3,"getDeviceId":2,
               "getSubscriberId":2,"getSimSerialNumber":2,"AccessibilityService":3,
               "REQUEST_INSTALL_PACKAGES":2,"SmsManager":3,"CallLog":2,"ContactsContract":2,
               "AudioRecord":2,"ClipboardManager":1,"PackageInstaller":3,"DevicePolicyManager":3,
               "Reflection":2,"Native lib loading":1,"Base64 decode":1,"Crypto Cipher":1,
               "InMemoryDexClassLoader":3,"JS Interface":2,"Root check":1,"Emulator check":1,
               "Debugger check":1,"Screen capture":3,"Keylogger pattern":3,"Overlay attack":3,
               "Remote admin":2}
    seen=set()
    for i in indicators:
        if i in seen: continue
        seen.add(i); score += weights.get(i,1); reasons.append(i)
    for x in net:
        c=x.get("classification","")
        if c=="Potential C2-like / control endpoint over HTTP": score+=4; reasons.append("C2-like HTTP endpoint heuristic")
        elif c=="Potential C2-like / control endpoint": score+=3; reasons.append("C2-like endpoint heuristic")
        elif c=="Potentially risky HTTP": score+=1
    score += min(6, len(yara.get("matches",[]))*2)
    if yara.get("matches"): reasons.append(f"YARA match(es): {len(yara['matches'])}")
    if abuse:
        for ip,res in abuse.items():
            conf=res.get("abuseConfidenceScore")
            if isinstance(conf,(int,float)):
                if conf>=75: score+=4; reasons.append(f"AbuseIPDB high-confidence reputation: {ip}")
                elif conf>=25: score+=2; reasons.append(f"AbuseIPDB elevated reputation: {ip}")
    if secrets:
        for sec in secrets:
            typ=sec["type"]
            if typ in ("Private Key (PEM)","AWS Access Key","Stripe Live Key"):
                score+=3; reasons.append(f"High-impact hardcoded secret: {typ}")
            elif typ=="Firebase DB URL":
                score+=1; reasons.append("Firebase database configuration detected; access rules require verification")
            else:
                score+=1; reasons.append(f"Potential secret: {typ}")
    if cert:
        for c in cert:
            if c.get("self_signed"):
                score+=2; reasons.append("APK uses a self-signed signing certificate")
            na=c.get("not_after")
            if na:
                try:
                    from datetime import datetime as _dt
                    if _dt.fromisoformat(na.replace("Z","+00:00")) < _dt.now(timezone.utc):
                        score+=2; reasons.append("APK signing certificate is expired")
                except Exception: pass
    if cloud_alerts:
        for a in cloud_alerts:
            if a.get("severity")=="HIGH": score+=4; reasons.append(f"Cloud configuration requires verification: {a['title']}")
            elif a.get("severity")=="MEDIUM": score+=1
    if manifest:
        for p in manifest.get("permissions_with_risk",[]):
            if p["risk"]=="CRITICAL": score+=2; reasons.append(f"Critical permission: {p['permission'].split('.')[-1]}")
            elif p["risk"]=="HIGH": score+=1
    if payloads:
        if payloads.get("apk"): score+=5; reasons.append(f"Embedded APK(s) detected: {len(payloads['apk'])}")
        if payloads.get("dex") and len(payloads["dex"])>5: score+=2; reasons.append(f"Multiple DEX files detected: {len(payloads['dex'])}")
    # Do not score OWASP again: OWASP findings are mappings of the evidence above.
    level="LOW" if score<=1 else "MEDIUM" if score<=5 else "HIGH" if score<=9 else "CRITICAL"
    return score,level,reasons

DEFAULT_OPTIONS = {
    "Basic APK Information": True,
    "Manifest & Permissions": True,
    "Extract Strings & Artifacts": True,
    "YARA Rule Scanning": True,
    "Network & Domain Analysis": True,
    "Threat Intelligence Lookup": True,
    "DEX / Static Code Indicators": True,
    "Detect Embedded Files": True,
    "Generate HTML / TXT / CSV Report": True,
}

def generate(apk, outdir, vt_key=None, abuseipdb_key=None, options=None):
    opt = dict(DEFAULT_OPTIONS)
    if options: opt.update(options)
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    sha=sha256_file(apk); md5=md5_file(apk)

    d = extract(apk)
    d["endpoint_intelligence"] = build_endpoint_intelligence(d.get("network", []))
    d["legal_correspondence"] = build_legal_correspondence(d.get("network", []))

    if not opt["Manifest & Permissions"]:
        d["permissions"] = []; d["manifest"] = {"parse_note":"skipped", "permissions_with_risk":[]}
    if not opt["Extract Strings & Artifacts"]:
        d["emails"] = []; d["phones"] = []
    if not opt["Network & Domain Analysis"]:
        d["urls"] = []; d["domains"] = []; d["network"] = []
        d["endpoint_intelligence"] = []; d["legal_correspondence"] = []
    if not opt["DEX / Static Code Indicators"]:
        d["indicators"] = []
        d["dex"] = {"dex_files":[],"classes":[],"method_count":0,"class_count":0,
                    "interesting_classes":[],"notes":["skipped"]}
    if not opt["Detect Embedded Files"]:
        d["embedded_apks"] = []
        d["payloads"] = {"apk":[],"dex":[],"jar":[],"zip":[],"db":[],"elf":[],"other_bin":[],"html":[],"js":[]}

    yara = yara_scan(apk) if opt["YARA Rule Scanning"] else {"available":False,"matches":[],"message":"YARA scan skipped (unchecked)."}

    vt = vt_hash_lookup(sha, vt_key) if opt["Threat Intelligence Lookup"] else {"status":"skipped"}
    abuse = {}
    if opt["Threat Intelligence Lookup"] and abuseipdb_key:
        for ip in d["ips"][:15]:
            host = ip.split(":")[0]
            abuse[ip] = abuseipdb_lookup(host, abuseipdb_key)

    scorev, level, reasons = score(
        d["indicators"], d["network"], yara, abuse, d["secrets"],
        d["certificates"], d["cloud_alerts"], d["manifest"], d["payloads"],
        d["owasp"]
    )

    now=datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S %z")

    data={
        "generated": now,
        "apk": apk.name,
        "size": apk.stat().st_size,
        "sha256": sha,
        "md5": md5,
        "urls": d["urls"],
        "domains": d["domains"],
        "ips": d["ips"],
        "emails": d["emails"],
        "phones": d["phones"],
        "permissions": d["permissions"],
        "permissions_with_risk": d["manifest"].get("permissions_with_risk", []),
        "indicators": d["indicators"],
        "embedded_apks": d["embedded_apks"],
        "network": d["network"],
        "endpoint_intelligence": d.get("endpoint_intelligence", []),
        "legal_correspondence": d.get("legal_correspondence", []),
        "yara": yara,
        "vt": vt,
        "abuseipdb": abuse,
        "sdks": d["sdks"],
        "secrets": d["secrets"],
        "certificates": d["certificates"],
        "manifest": d["manifest"],
        "dex": d["dex"],
        "native_libs": d["native_libs"],
        "structure": d["structure"],
        "payloads": d["payloads"],
        "library_versions": d["library_versions"],
        "cloud_alerts": d["cloud_alerts"],
        "owasp": d["owasp"],
        "score": scorev,
        "level": level,
        "reasons": reasons,
        "options": opt,
    }

    base=outdir/(apk.stem+"_forensic_report")
    (base.with_suffix(".json")).write_text(json.dumps(data,indent=2),encoding="utf-8")

    if not opt["Generate HTML / TXT / CSV Report"]:
        return base, data

    with open(base.with_suffix(".csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["url","domain","provider","type","classification"])
        w.writeheader(); w.writerows(d["network"])

    txt = build_txt_report(data)
    base.with_suffix(".txt").write_text("\n".join(txt),encoding="utf-8")
    page = render_html(data)
    base.with_suffix(".html").write_text(page,encoding="utf-8")
    return base, data

def build_txt_report(d):
    txt=[]
    txt += ["ANDROID APK FORENSIC REPORT v3.3 — POLICE FORENSIC EDITION","="*72,
            f"Generated: {d['generated']}",f"APK: {d['apk']}",
            f"Size: {d['size']:,}",f"SHA-256: {d['sha256']}",f"MD5: {d['md5']}","",
            f"TRIAGE RISK: {d['level']} (evidence-weighted score {d['score']})",""]
    if d.get("reasons"):
        txt += ["RISK REASONS","-"*72]+[f"- {r}" for r in d["reasons"]]+[""]

    # OWASP
    owasp = d.get("owasp") or {}
    txt += ["OWASP MOBILE TOP 10 (2024)","-"*72]
    s = owasp.get("summary", {})
    txt.append(f"Total issues: {s.get('total',0)}")
    by_sev = s.get("by_severity", {})
    if by_sev:
        txt.append("By severity: " + ", ".join(f"{k}={v}" for k,v in by_sev.items()))
    for f in owasp.get("findings", []):
        txt.append(f"- [{f['severity']}] {f['id']} {f['category']}: {f['title']}")
        txt.append(f"    Evidence: {f['evidence']}")
        txt.append(f"    MASVS: {f['masvs']}")
    if not owasp.get("findings"):
        txt.append("- No OWASP issues found")
    txt.append("")

    if d.get("cloud_alerts"):
        txt += ["⚠ CLOUD MISCONFIGURATION ALERTS","-"*72]
        for a in d["cloud_alerts"]:
            txt += [f"[{a['severity']}] {a['title']}",
                    f"  {a['detail']}",
                    f"  Test: {a.get('test_url','—')}",
                    f"  Fix: {a['fix']}",""]
    txt += ["DETECTED SDKs","-"*72]
    for s_ in d["sdks"]:
        txt.append(f"- {s_['sdk']} ({s_['category']})")
    if not d["sdks"]: txt.append("- None")
    txt += ["","HARDCODED SECRETS","-"*72]
    for sec in d["secrets"]:
        txt.append(f"- [{sec['type']}] {sec['value']}")
    if not d["secrets"]: txt.append("- None")
    txt += ["","DANGEROUS PERMISSIONS","-"*72]
    for p in d.get("permissions_with_risk", []):
        txt.append(f"- [{p['risk']}] {p['permission']} — {p['desc']}")
    if not d.get("permissions_with_risk"): txt.append("- None")
    txt += ["","APK CERTIFICATES","-"*72]
    for c in d["certificates"]:
        txt.append(f"- {c.get('entry')}  self_signed={c.get('self_signed')}")
    if not d["certificates"]: txt.append("- None")
    txt += ["","NATIVE LIBRARIES (.so)","-"*72]
    for l in d.get("native_libs", []):
        txt.append(f"- [{l['arch']}] {l['path']} ({l['size']:,} bytes)")
    if not d.get("native_libs"): txt.append("- None")
    txt += ["","EMBEDDED PAYLOADS","-"*72]
    for kind, items in (d.get("payloads") or {}).items():
        for it in items[:20]:
            txt.append(f"- [{kind}] {it['name']} ({it['size']:,} bytes)")
    if not any(d.get("payloads", {}).values()): txt.append("- None")
    txt += ["","LIBRARY VERSIONS","-"*72]
    for lib, vers in (d.get("library_versions") or {}).items():
        txt.append(f"- {lib}: {', '.join(vers)}")
    if not d.get("library_versions"): txt.append("- None detected")
    txt += ["","CODE INDICATORS","-"*72]+[f"- {x}" for x in d["indicators"]]+[""]
    txt += ["YARA","-"*72]
    for x in d["yara"].get("matches",[]):
        txt.append(f"- {x['rule']} ({', '.join(x['tags'])})")
    if not d["yara"].get("matches"): txt.append("- "+d["yara"].get("message","No matches."))
    txt += ["","IP ADDRESSES","-"*72] + ([f"- {x}" for x in d["ips"]] or ["- None detected"])
    txt += ["","MOBILE NUMBERS","-"*72] + ([f"- {x}" for x in d["phones"]] or ["- None detected"])
    txt += ["","EMAIL IDs","-"*72] + ([f"- {x}" for x in d["emails"]] or ["- None detected"])
    txt += ["","INVESTIGATIVE ENDPOINTS","-"*72]
    for e in d.get("endpoint_intelligence", []):
        txt.append(f"- [{e['endpoint_type']}] {e['provider']} | {e['url']} | {e['investigative_value']}")
    if not d.get("endpoint_intelligence"): txt.append("- None")
    txt += ["","📮 LEGAL CORRESPONDENCE — PROVIDERS IDENTIFIED (who to contact for account details)","-"*72]
    for c in d.get("legal_correspondence", []):
        txt.append(f"- {c['provider']}" + (f" ({c['company']})" if c.get('company') else ""))
        if c.get("contact_url"):
            txt.append(f"    Contact/legal-request page: {c['contact_url']}")
        txt.append(f"    Note: {c['note']}")
        txt.append(f"    Seen at: {', '.join(c['urls'][:5])}" + (" ..." if len(c['urls'])>5 else ""))
    if not d.get("legal_correspondence"): txt.append("- No identifiable third-party providers found.")
    txt += ["","REAL NETWORK URLs","-"*72]
    for x in d["network"]: txt.append(f"{x['url']} | {x['provider']} | {x['classification']}")
    if not d["network"]: txt.append("- None")
    txt += ["","VIRUSTOTAL HASH LOOKUP","-"*72, json.dumps(d["vt"],indent=2)]
    txt += ["","ABUSEIPDB IP REPUTATION","-"*72,
            json.dumps(d["abuseipdb"],indent=2) if d["abuseipdb"] else "- Not configured / no IPs to check."]
    txt += ["","NOTE: Static triage only. Findings are investigative leads and require manual/decompilation/dynamic validation; absence of a finding does not establish absence of the underlying behavior."]
    return txt

def render_html(d):
    esc=lambda x:html.escape(str(x))
    rows="".join(f"<tr><td>{esc(x['url'])}</td><td>{esc(x['provider'])}</td><td>{esc(x['type'])}</td><td>{esc(x['classification'])}</td></tr>" for x in d["network"])
    yara="".join(f"<tr><td>{esc(x['rule'])}</td><td>{esc(', '.join(x['tags']))}</td></tr>" for x in d["yara"].get("matches",[]))
    if not yara: yara=f"<tr><td colspan='2'>{esc(d['yara'].get('message','No YARA matches'))}</td></tr>"
    vt=d["vt"]; vtlink=vt.get("url",f"https://www.virustotal.com/gui/file/{d['sha256']}")
    abuse=d.get("abuseipdb") or {}
    if abuse:
        abuse_rows="".join(
            f"<tr><td>{esc(ip)}</td><td>{esc(r.get('abuseConfidenceScore','—'))}</td>"
            f"<td>{esc(r.get('countryCode','—'))}</td><td>{esc(r.get('isp','—'))}</td>"
            f"<td>{esc(r.get('totalReports','—'))}</td>"
            f"<td><a href='{esc(r.get('url','#'))}' target='_blank'>View</a></td></tr>"
            for ip,r in abuse.items()
        )
    else:
        abuse_rows="<tr><td colspan='6'>Not configured, or no IPs found to check.</td></tr>"
    sdks_by_cat = {}
    for s in d.get("sdks", []):
        sdks_by_cat.setdefault(s["category"], []).append(s["sdk"])
    sdk_cat_rows = "".join(
        f"<tr><td><b>{esc(cat)}</b></td><td>{esc(', '.join(sorted(set(sdks))))}</td></tr>"
        for cat, sdks in sorted(sdks_by_cat.items())
    ) or "<tr><td colspan='2'>No SDK signatures matched</td></tr>"
    sdk_rows = "".join(
        f"<tr><td>{esc(s['sdk'])}</td><td>{esc(s['category'])}</td></tr>"
        for s in d.get("sdks", [])
    ) or "<tr><td colspan='2'>No SDK signatures matched</td></tr>"
    secret_rows = "".join(
        f"<tr><td>{esc(s['type'])}</td><td><code>{esc(s['value'])}</code></td>"
        f"<td class='small'>{esc(s['context'])}</td></tr>"
        for s in d.get("secrets", [])
    ) or "<tr><td colspan='3'>No high-confidence secrets detected</td></tr>"
    cert_rows = "".join(
        f"<tr><td>{esc(c.get('entry'))}</td><td>{esc(c.get('subject','—'))}</td>"
        f"<td>{esc(c.get('issuer','—'))}</td>"
        f"<td>{esc(c.get('not_before','—'))} → {esc(c.get('not_after','—'))}</td>"
        f"<td>{esc(c.get('self_signed','—'))}</td>"
        f"<td><code>{esc(c.get('sha256_fingerprint','—')[:32])}…</code></td></tr>"
        for c in d.get("certificates", [])
    ) or "<tr><td colspan='6'>No signing certificate found</td></tr>"
    perm_rows = "".join(
        f"<tr><td><code>{esc(p['permission'])}</code></td>"
        f"<td class='risk-{p['risk']}'>{esc(p['risk'])}</td>"
        f"<td>{esc(p['desc'])}</td></tr>"
        for p in d.get("permissions_with_risk", [])
    ) or "<tr><td colspan='3'>No permissions parsed</td></tr>"
    deep_rows = "".join(f"<li><code>{esc(x)}</code></li>" for x in d.get("manifest", {}).get("deep_links", [])) or "<li>None</li>"
    dex = d.get("dex", {})
    dex_rows = "".join(
        f"<tr><td>{esc(x.get('name'))}</td><td>{x.get('size',0):,}</td>"
        f"<td>{x.get('class_defs','—')}</td><td>{x.get('method_ids','—')}</td>"
        f"<td>{x.get('string_ids','—')}</td></tr>"
        for x in dex.get("dex_files", [])
    ) or "<tr><td colspan='5'>No DEX files</td></tr>"
    ic_rows = "".join(f"<li><code>{esc(c)}</code></li>"
                      for c in dex.get("interesting_classes", [])[:100]) or "<li>None</li>"
    native_rows = "".join(
        f"<tr><td>{esc(l['path'])}</td><td>{esc(l['arch'])}</td>"
        f"<td>{l['size']:,}</td><td><code>{esc(l['sha256_short'])}</code></td></tr>"
        for l in d.get("native_libs", [])
    ) or "<tr><td colspan='4'>No native libraries</td></tr>"
    struct = d.get("structure", {})
    struct_ext_rows = "".join(
        f"<tr><td>{esc(k)}</td><td>{v}</td></tr>"
        for k, v in (struct.get("by_extension") or {}).items()
    ) or "<tr><td colspan='2'>—</td></tr>"
    payloads = d.get("payloads", {}) or {}
    payload_rows = ""
    for kind, items in payloads.items():
        for it in items[:30]:
            payload_rows += (f"<tr><td>{esc(kind)}</td><td>{esc(it['name'])}</td>"
                             f"<td>{it['size']:,}</td></tr>")
    if not payload_rows:
        payload_rows = "<tr><td colspan='3'>No embedded payloads detected</td></tr>"
    libver_rows = "".join(
        f"<tr><td>{esc(lib)}</td><td>{esc(', '.join(vers))}</td></tr>"
        for lib, vers in (d.get("library_versions") or {}).items()
    ) or "<tr><td colspan='2'>No library versions detected</td></tr>"
    cloud_html = ""
    for a in d.get("cloud_alerts", []):
        sev = a.get("severity","MEDIUM")
        border = "#a00000" if sev == "HIGH" else "#8a5a00"
        cloud_html += f"""
        <div style="border:2px solid {border};border-radius:8px;padding:14px;margin:10px 0;background:#fff5f5">
          <div style="font-size:16px;font-weight:bold;color:{border}">⚠ {esc(a['title'])} ({esc(sev)})</div>
          <p>{esc(a['detail'])}</p>
          <p><b>Test URL:</b> <code>{esc(a.get('test_url','—'))}</code></p>
          <p><b>Fix:</b> {esc(a['fix'])}</p>
        </div>"""
    if not cloud_html:
        cloud_html = "<p class='small'>No cloud misconfiguration detected.</p>"
    reasons_html = "".join(f"<li>{esc(r)}</li>" for r in d.get("reasons", [])) or "<li>No specific risk reasons</li>"

    # OWASP section
    owasp = d.get("owasp") or {}
    owasp_findings = owasp.get("findings", [])
    owasp_summary = owasp.get("summary", {})
    sev_color = {"CRITICAL":"#a00000","HIGH":"#c94b00","MEDIUM":"#8a5a00",
                 "LOW":"#287a3e","INFO":"#666"}
    owasp_rows = ""
    for f in owasp_findings:
        c = sev_color.get(f["severity"], "#666")
        owasp_rows += (
            f"<tr>"
            f"<td><b>{esc(f['id'])}</b></td>"
            f"<td>{esc(f['category'])}</td>"
            f"<td style='color:{c};font-weight:bold'>{esc(f['severity'])}</td>"
            f"<td>{esc(f['title'])}<br><span class='small'>{esc(f['evidence'])}</span></td>"
            f"<td class='small'>{esc(f['masvs'])}</td>"
            f"</tr>"
        )
    if not owasp_rows:
        owasp_rows = "<tr><td colspan='5'>No OWASP issues found (good!)</td></tr>"
    sev_chips = ""
    for sev in ("CRITICAL","HIGH","MEDIUM","LOW","INFO"):
        cnt = owasp_summary.get("by_severity", {}).get(sev, 0)
        if cnt:
            c = sev_color.get(sev, "#666")
            sev_chips += f"<span style='background:{c};color:white;padding:3px 10px;border-radius:12px;margin:4px;font-size:12px;font-weight:bold;display:inline-block'>{sev}: {cnt}</span>"
    masvs_chips = ""
    for m in owasp_summary.get("masvs_covered", []):
        masvs_chips += f"<span style='background:#1d4664;color:white;padding:3px 10px;border-radius:12px;margin:4px;font-size:11px;display:inline-block'>{esc(m)}</span>"
    owasp_html = f"""
    <div class="card" style="background:#fafbfc">
      <div style="font-size:14px;margin-bottom:8px">Found <b>{owasp_summary.get('total',0)}</b> issue(s) mapped to OWASP Mobile Top 10 (2024):</div>
      <div>{sev_chips or 'No issues'}</div>
      <div style="margin-top:10px"><b class="small">MASVS Coverage:</b><br>{masvs_chips or '<span class="small">None</span>'}</div>
    </div>
    <div class='scroll'><table>
      <tr><th style="width:50px">ID</th><th>Category</th><th style="width:90px">Severity</th><th>Finding</th><th>MASVS</th></tr>
      {owasp_rows}
    </table></div>
    """

    checklist_html = """
    <div class="card">
      <h3>Immediate Actions</h3>
      <ul>
        <li>☐ VirusTotal पर SHA-256 verify करें</li>
        <li>☐ Developer certificate verify करें (self-signed = suspicious)</li>
        <li>☐ Firebase/Supabase URLs publicly accessible हैं या नहीं check करें</li>
        <li>☐ Any exposed API keys rotate करें</li>
        <li>☐ Embedded APKs / DEX files check करें</li>
        <li>☐ OWASP Mobile Top 10 findings review करें</li>
      </ul>
      <h3>Deep Analysis</h3>
      <ul>
        <li>☐ Decompile with jadx / apktool</li>
        <li>☐ Native .so files Ghidra से check करें</li>
        <li>☐ Dynamic analysis with Frida</li>
        <li>☐ Network capture with mitmproxy</li>
      </ul>
      <h3>Legal / Reporting</h3>
      <ul>
        <li>☐ Findings को case file में document करें</li>
        <li>☐ Hash + timestamp को notarize करें</li>
        <li>☐ अगर malware confirmed है तो CERT-In को report करें</li>
      </ul>
    </div>"""

    return f"""<!doctype html><html><head><meta charset='utf-8'><title>Android APK Forensic Report v3.3 — Police Forensic Edition</title>
<style>
body{{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;color:#17202a}} .wrap{{max-width:1200px;margin:auto;background:white;padding:28px}}
h1{{margin:0 0 6px}} h2{{border-bottom:2px solid #ddd;padding-bottom:7px;margin-top:28px}}
h3{{margin:14px 0 6px}}
button,.btn{{display:inline-block;padding:10px 14px;margin:4px;border:0;border-radius:6px;background:#7b2d26;color:white;text-decoration:none;cursor:pointer}}
.card{{border:1px solid #ddd;border-radius:8px;padding:14px;margin:10px 0}} table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{border-bottom:1px solid #ddd;padding:7px;text-align:left;vertical-align:top}} th{{background:#f0f0f0}}
.risk{{font-size:24px;font-weight:bold}} .HIGH,.CRITICAL{{color:#a00000}} .MEDIUM{{color:#8a5a00}} .LOW{{color:#287a3e}}
.risk-CRITICAL{{color:#a00000;font-weight:bold}} .risk-HIGH{{color:#c94b00;font-weight:bold}}
.risk-MEDIUM{{color:#8a5a00}} .risk-LOW{{color:#287a3e}} .risk-UNKNOWN{{color:#666}}
.small{{font-size:12px;color:#555}} .scroll{{max-height:520px;overflow:auto}} code{{background:#f0f0f0;padding:2px 4px;border-radius:3px;font-size:12px}}
.stats{{display:flex;gap:12px;flex-wrap:wrap;margin:10px 0}}
.stat{{border:1px solid #ddd;border-radius:8px;padding:10px 14px;flex:1;min-width:150px;text-align:center}}
.stat b{{display:block;font-size:22px;color:#7b2d26}}
</style></head><body><div class='wrap'>
<h1>ANDROID APK FORENSIC ANALYSIS <span class="small">v3.3</span></h1>
<div class='small'>Generated: {esc(d['generated'])}</div>
<div><button onclick='downloadHTML()'>⬇ Download Report</button>
<a class='btn' href='{esc(vtlink)}' target='_blank'>🔗 Open VirusTotal</a></div>

<div class='card'><b>Risk Level:</b> <span class='risk {esc(d["level"])}'>{esc(d["level"])}</span> — score {d["score"]}<br>
<span class='small'>Triage indicator only; not a definitive malware verdict.</span></div>

<div class="stats">
  <div class="stat"><b>{len(d.get('sdks',[]))}</b>SDKs</div>
  <div class="stat"><b>{len(d.get('secrets',[]))}</b>Secrets</div>
  <div class="stat"><b>{len(d.get('domains',[]))}</b>Domains</div>
  <div class="stat"><b>{len(d.get('network',[]))}</b>URLs</div>
  <div class="stat"><b>{len(d.get('native_libs',[]))}</b>Native libs</div>
  <div class="stat"><b>{len(d.get('permissions_with_risk',[]))}</b>Permissions</div>
  <div class="stat"><b>{dex.get('class_count',0)}</b>DEX classes</div>
  <div class="stat"><b>{owasp_summary.get('total',0)}</b>OWASP issues</div>
</div>

<div class='card'><b>Risk Reasons</b><ul>{reasons_html}</ul></div>

<h2>🛡 OWASP Mobile Top 10 (2024) Analysis</h2>
{owasp_html}

{'<h2>⚠ Cloud Misconfiguration Alerts</h2>' + cloud_html if d.get('cloud_alerts') else ''}

<h2>File Information</h2><table>
<tr><th>APK</th><td>{esc(d['apk'])}</td></tr>
<tr><th>Size</th><td>{d['size']:,} bytes</td></tr>
<tr><th>SHA-256</th><td><code>{d['sha256']}</code></td></tr>
<tr><th>MD5</th><td><code>{d['md5']}</code></td></tr>
</table>

<h2>APK Signing Certificate</h2>
<div class='scroll'><table><tr><th>Entry</th><th>Subject</th><th>Issuer</th><th>Validity</th><th>Self-signed</th><th>SHA-256 FP</th></tr>{cert_rows}</table></div>

<h2>Detected SDKs ({len(d.get('sdks',[]))}) — Grouped by Category</h2>
<div class='scroll'><table><tr><th>Category</th><th>SDKs</th></tr>{sdk_cat_rows}</table></div>
<details><summary style="cursor:pointer;padding:8px 0">Full SDK list</summary>
<div class='scroll'><table><tr><th>SDK</th><th>Category</th></tr>{sdk_rows}</table></div></details>

<h2>Third-Party Library Versions</h2>
<div class='scroll'><table><tr><th>Library</th><th>Version(s)</th></tr>{libver_rows}</table></div>

<h2>Hardcoded Secrets / API Keys ({len(d.get('secrets',[]))})</h2>
<div class='scroll'><table><tr><th>Type</th><th>Value</th><th>Context</th></tr>{secret_rows}</table></div>

<h2>Dangerous Permissions ({len(d.get('permissions_with_risk',[]))})</h2>
<div class='scroll'><table><tr><th>Permission</th><th>Risk</th><th>Description</th></tr>{perm_rows}</table></div>

<h2>Manifest — Deep Links</h2>
<div class='card'><div class='scroll'><ul>{deep_rows}</ul></div></div>

<h2>APK Structure</h2>
<div class="stats">
  <div class="stat"><b>{struct.get('total_files',0)}</b>Total files</div>
  <div class="stat"><b>{struct.get('total_size',0)//1024}</b>KB unpacked</div>
  <div class="stat"><b>{struct.get('dex_count',0)}</b>DEX files</div>
  <div class="stat"><b>{struct.get('so_count',0)}</b>.so files</div>
  <div class="stat"><b>{struct.get('res_count',0)}</b>res files</div>
  <div class="stat"><b>{struct.get('assets_count',0)}</b>assets files</div>
</div>
<details><summary style="cursor:pointer;padding:8px 0">File types breakdown</summary>
<div class='scroll'><table><tr><th>Extension</th><th>Count</th></tr>{struct_ext_rows}</table></div></details>

<h2>DEX Summary</h2>
<div class='card'>Total classes: <b>{dex.get('class_count',0)}</b> | Total methods: <b>{dex.get('method_count',0)}</b></div>
<div class='scroll'><table><tr><th>DEX</th><th>Size</th><th>Classes</th><th>Methods</th><th>Strings</th></tr>{dex_rows}</table></div>

<h2>Interesting Class Names ({len(dex.get('interesting_classes',[]))})</h2>
<div class='scroll'><ul>{ic_rows}</ul></div>

<h2>Native Libraries (.so) ({len(d.get('native_libs',[]))})</h2>
<div class='scroll'><table><tr><th>Path</th><th>Arch</th><th>Size</th><th>SHA-256 (short)</th></tr>{native_rows}</table></div>

<h2>Embedded Payloads</h2>
<div class='scroll'><table><tr><th>Type</th><th>Name</th><th>Size</th></tr>{payload_rows}</table></div>

<h2>Code Indicators</h2><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['indicators']) or '<li>None detected</li>'}</ul>

<h2>YARA Results</h2><table><tr><th>Rule</th><th>Tags</th></tr>{yara}</table>

<h2>🔎 Investigative Endpoints</h2>
<div class='card' style='border:2px solid #7b2d26'><b>Highlighted infrastructure</b><div class='small'>These endpoints may identify application databases, storage, authentication services, APIs or cloud backends. The analyzer only reports static references; it does not automatically access, enumerate, modify or download data.</div></div>
<div class='scroll'><table><tr><th>Endpoint</th><th>Provider</th><th>Type</th><th>Investigative Value</th></tr>{''.join(f"<tr style='background:#fff8e8'><td><code>{esc(e['url'])}</code></td><td><b>{esc(e['provider'])}</b></td><td>{esc(e['endpoint_type'])}</td><td>{esc(e['investigative_value'])}</td></tr>" for e in d.get('endpoint_intelligence', [])) or '<tr><td colspan=4>No known database/storage/auth/API infrastructure endpoints identified.</td></tr>'}</table></div>

<h2>📮 Legal Correspondence — Providers Identified</h2>
<div class='card' style='border:2px solid #1d4664'><b>Who to contact for subscriber/account details</b><div class='small'>Every third-party service found in this APK is listed below with its operating company and official legal-request/law-enforcement channel where one is on file. Use these to send a preservation letter, subpoena, or MLAT request for the account holder, registration IP, or billing details behind the identified project/bucket/number. This tool does not contact these companies automatically.</div></div>
<div class='scroll'>{''.join(
    f"<div class='card' style='border-left:4px solid {'#287a3e' if c['has_curated_contact'] else '#8a5a00'}'>"
    f"<b>{esc(c['provider'])}</b>" + (f" — {esc(c['company'])}" if c.get('company') else "") + "<br>"
    + (f"<a class='btn' style='background:#1d4664' href='{esc(c['contact_url'])}' target='_blank'>🔗 Legal request page</a><br>" if c.get('contact_url') else "")
    + f"<span class='small'>{esc(c['note'])}</span><br>"
    + f"<span class='small'>Seen at: {esc(', '.join(c['urls'][:5]))}{' ...' if len(c['urls'])>5 else ''}</span>"
    f"</div>"
    for c in d.get('legal_correspondence', [])
) or "<p class='small'>No identifiable third-party providers found in this APK.</p>"}</div>

<h2>Real Network URLs / Infrastructure ({len(d.get('network',[]))})</h2>
<div class='scroll'><table><tr><th>URL</th><th>Provider</th><th>Type</th><th>Classification</th></tr>{rows or '<tr><td colspan=4>None</td></tr>'}</table></div>

<h2>High-Confidence Contact / Network Indicators</h2>
<div class='card'><b>High-Confidence Mobile Numbers ({len(d['phones'])})</b><div class='scroll'><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['phones']) or '<li>None detected</li>'}</ul></div></div>
<div class='card'><b>Email IDs ({len(d['emails'])})</b><div class='scroll'><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['emails']) or '<li>None detected</li>'}</ul></div></div>
<div class='card'><b>IP Addresses ({len(d['ips'])})</b><div class='scroll'><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['ips']) or '<li>None detected</li>'}</ul></div></div>
<div class='card'><b>Real Domains ({len(d['domains'])})</b><div class='scroll'><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['domains']) or '<li>None detected</li>'}</ul></div></div>
<div class='card'><b>Embedded APKs ({len(d['embedded_apks'])})</b><div class='scroll'><ul>{''.join('<li>'+esc(x)+'</li>' for x in d['embedded_apks']) or '<li>None detected</li>'}</ul></div></div>

<h2>VirusTotal</h2><div class='card'>Status: <b>{esc(vt.get('status'))}</b><br><a href='{esc(vtlink)}' target='_blank'>Open VirusTotal hash report</a></div>

<h2>AbuseIPDB — IP Reputation</h2>
<div class='scroll'><table><tr><th>IP</th><th>Abuse Confidence</th><th>Country</th><th>ISP</th><th>Reports</th><th>Link</th></tr>{abuse_rows}</table></div>

<h2>Potential C2 Indicators</h2>
<ul>{''.join('<li>'+esc(x['url'])+' — '+esc(x['classification'])+'</li>' for x in d['network'] if 'C2' in x['classification']) or '<li>No C2-like URL pattern identified by static heuristics.</li>'}</ul>

<h2>🔍 Investigation Checklist</h2>
{checklist_html}

<h2>Important Note</h2><p class='small'>Static analysis only. Findings are heuristic investigative leads and require manual/decompilation/dynamic validation. OWASP findings are static heuristics — manual verification is required.</p>
</div>
<script>
function downloadHTML(){{const blob=new Blob([document.documentElement.outerHTML],{{type:'text/html'}});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='{esc(d["apk"])}_forensic_report.html';a.click();URL.revokeObjectURL(a.href);}}
</script></body></html>"""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("apk")
    ap.add_argument("--out", default="")
    ap.add_argument("--vt-key",default=os.getenv("VT_API_KEY"))
    ap.add_argument("--abuseipdb-key",default=os.getenv("ABUSEIPDB_API_KEY"))
    ap.add_argument("--no-yara",action="store_true",help="Skip YARA scanning")
    ap.add_argument("--no-threat-intel",action="store_true",help="Skip VirusTotal / AbuseIPDB lookups")
    args=ap.parse_args()
    out=args.out or str(Path(args.apk).parent/"AndroidForensicReports")
    options=dict(DEFAULT_OPTIONS)
    if args.no_yara: options["YARA Rule Scanning"]=False
    if args.no_threat_intel: options["Threat Intelligence Lookup"]=False
    base,data=generate(Path(args.apk),out,args.vt_key,args.abuseipdb_key,options)
    print(f"HTML: {base.with_suffix('.html')}")
    print(f"TXT : {base.with_suffix('.txt')}")
    print(f"CSV : {base.with_suffix('.csv')}")
    print(f"JSON: {base.with_suffix('.json')}")
    print(f"\nRisk: {data['level']} (score {data['score']})")
    owasp = data.get("owasp", {})
    print(f"OWASP: {owasp.get('summary',{}).get('total',0)} issue(s)")

if __name__=="__main__": main()