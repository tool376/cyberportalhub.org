@echo off
setlocal EnableDelayedExpansion
title Android APK Analyzer v3.3 - Builder
color 0B

echo.
echo ============================================================
echo    ANDROID APK ANALYZER v3.3 - EXE BUILDER
echo ============================================================
echo.

echo [1/6] Python check...
where python >nul 2>nul
if errorlevel 1 (
    echo    [X] Python install nahi hai!
    echo    https://www.python.org/downloads/ se install karein
    echo    "Add Python to PATH" tick karna zaroori hai.
    pause
    exit /b 1
)
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo    [OK] Python %PYVER%

echo.
echo [2/6] pip check...
python -m pip --version >nul 2>nul
if errorlevel 1 python -m ensurepip --upgrade
echo    [OK] pip ready

echo.
echo [3/6] Libraries install kar rahe hain...
python -m pip install --upgrade pip --quiet

REM Core deps (requests, cryptography) are required -- install explicitly first
REM so a yara-python build failure elsewhere can never silently take these down.
python -m pip install "requests>=2.31" "cryptography>=42.0.0" --quiet
if errorlevel 1 (
    echo    [X] Core dependencies (requests/cryptography) install fail hua!
    echo    Internet connection check karein ya Python version try karein.
    pause
    exit /b 1
)
echo    [OK] Core dependencies (requests, cryptography) install

python -m pip install pyinstaller --quiet
if errorlevel 1 (
    echo    [X] PyInstaller install fail
    pause
    exit /b 1
)
echo    [OK] pyinstaller install

echo    yara-python try kar rahe hain (optional)...
python -m pip install yara-python --quiet
if errorlevel 1 (
    echo    [!] yara-python skip - YARA scan nahi chalega, baaki sab theek
    set YARA_OK=0
) else (
    echo    [OK] yara-python install
    set YARA_OK=1
)

echo.
echo [4/6] Files check...
set MISSING=0
if not exist "android_forensic.py"       ( echo    [X] android_forensic.py nahi mila & set MISSING=1 )
if not exist "android_forensic_gui.py"   ( echo    [X] android_forensic_gui.py nahi mila & set MISSING=1 )
if not exist "rules\android_triage.yar"  ( echo    [!] rules\android_triage.yar nahi mila - YARA optional rahega )

if "!MISSING!"=="1" (
    echo    Kripya ye files isi folder mein rakhein.
    pause
    exit /b 1
)
echo    [OK] Saari files mil gayi

echo.
echo [5/6] EXE build kar rahe hain... (5-8 minute lagenge)
echo.

if exist "build" rmdir /s /q "build" >nul 2>nul
if exist "dist"  rmdir /s /q "dist"  >nul 2>nul
if exist "AndroidAPKAnalyzerV3.spec" del /q "AndroidAPKAnalyzerV3.spec" >nul 2>nul

set "YARA_HIDDEN="
if "!YARA_OK!"=="1" set "YARA_HIDDEN=--hidden-import yara"

python -m PyInstaller --onefile --windowed ^
  --name AndroidAPKAnalyzerV3 ^
  --add-data "rules;rules" ^
  --hidden-import cryptography ^
  !YARA_HIDDEN! ^
  --clean ^
  android_forensic_gui.py

if not exist "dist\AndroidAPKAnalyzerV3.exe" (
    echo.
    echo    [X] EXE build fail hua!
    echo    Upar ke errors dekhein.
    pause
    exit /b 1
)
echo.
echo    [OK] EXE ban gaya!

echo.
echo [6/6] Desktop shortcut...

set "EXEPATH=%CD%\dist\AndroidAPKAnalyzerV3.exe"
set "SHORTCUT=%USERPROFILE%\Desktop\Android APK Analyzer.lnk"

powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%EXEPATH%'; $s.WorkingDirectory = '%CD%\dist'; $s.IconLocation = '%EXEPATH%,0'; $s.Save()" >nul 2>nul

if exist "%SHORTCUT%" (
    echo    [OK] Desktop shortcut ban gaya
) else (
    echo    [!] Shortcut nahi bana - dist folder se manually chala sakte hain
)

echo.
echo ============================================================
echo    SETUP COMPLETE!
echo ============================================================
echo.
echo    EXE: %EXEPATH%
echo    Desktop: "Android APK Analyzer"
echo.

choice /C YN /M "Kya abhi EXE chalu karna hai"
if errorlevel 2 goto END
start "" "%EXEPATH%"

:END
echo.
timeout /t 3 >nul
endlocal
exit /b 0